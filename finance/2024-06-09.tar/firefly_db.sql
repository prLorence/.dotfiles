/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: firefly
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `2fa_tokens`
--

DROP TABLE IF EXISTS `2fa_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `2fa_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `expires_at` datetime NOT NULL,
  `token` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `2fa_tokens_token_unique` (`token`),
  KEY `2fa_tokens_user_id_foreign` (`user_id`),
  CONSTRAINT `2fa_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2fa_tokens`
--

LOCK TABLES `2fa_tokens` WRITE;
/*!40000 ALTER TABLE `2fa_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `2fa_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_balances`
--

DROP TABLE IF EXISTS `account_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_balances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `transaction_currency_id` int(10) unsigned NOT NULL,
  `date` date DEFAULT NULL,
  `transaction_journal_id` int(10) unsigned DEFAULT NULL,
  `balance` decimal(32,12) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_account_currency` (`account_id`,`transaction_currency_id`,`transaction_journal_id`,`date`,`title`),
  KEY `account_balances_transaction_journal_id_foreign` (`transaction_journal_id`),
  KEY `account_balances_transaction_currency_id_foreign` (`transaction_currency_id`),
  CONSTRAINT `account_balances_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `account_balances_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `account_balances_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_balances`
--

LOCK TABLES `account_balances` WRITE;
/*!40000 ALTER TABLE `account_balances` DISABLE KEYS */;
INSERT INTO `account_balances` VALUES
(1,'2024-05-25 14:54:13','2024-06-09 15:02:45','balance',2,25,NULL,NULL,-6000.410000000000),
(2,'2024-05-25 14:54:13','2024-06-09 15:02:45','balance',1,25,NULL,NULL,0.730000000000),
(3,'2024-05-25 14:54:13','2024-06-09 15:02:45','balance',4,25,NULL,NULL,-3900.780000000000),
(4,'2024-05-25 14:54:13','2024-06-09 15:02:45','balance',3,25,NULL,NULL,6762.950000000000),
(5,'2024-05-25 15:05:50','2024-06-09 15:02:45','balance',9,25,NULL,NULL,6307.680000000000),
(6,'2024-05-25 15:09:41','2024-06-09 15:02:45','balance',8,25,NULL,NULL,3813.000000000000),
(7,'2024-05-31 14:09:59','2024-06-09 15:02:45','balance',10,25,NULL,NULL,-5500.000000000000),
(8,'2024-05-31 23:18:55','2024-06-09 15:02:45','balance',5,25,NULL,NULL,200.000000000000),
(9,'2024-05-31 23:22:35','2024-06-09 15:02:45','balance',6,25,NULL,NULL,-1683.170000000000),
(10,'2024-06-05 21:29:14','2024-06-09 15:02:45','balance',13,25,NULL,NULL,674.490000000000),
(11,'2024-06-05 21:29:14','2024-06-09 15:02:45','balance',12,25,NULL,NULL,-674.490000000000),
(12,'2024-06-05 21:29:14','2024-06-09 15:02:45','balance',14,25,NULL,NULL,0.000000000000),
(13,'2024-06-05 21:34:11','2024-06-09 15:02:45','balance',16,25,NULL,NULL,3081.000000000000),
(14,'2024-06-05 21:34:11','2024-06-09 15:02:45','balance',15,25,NULL,NULL,-3081.000000000000),
(15,'2024-06-05 21:34:11','2024-06-09 15:02:45','balance',17,25,NULL,NULL,0.000000000000);
/*!40000 ALTER TABLE `account_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_meta`
--

DROP TABLE IF EXISTS `account_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_meta_account_id_index` (`account_id`),
  CONSTRAINT `account_meta_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_meta`
--

LOCK TABLES `account_meta` WRITE;
/*!40000 ALTER TABLE `account_meta` DISABLE KEYS */;
INSERT INTO `account_meta` VALUES
(1,'2024-05-25 14:54:13','2024-05-25 14:54:13',1,'account_role','\"defaultAsset\"'),
(2,'2024-05-25 14:54:13','2024-05-25 14:54:13',1,'currency_id','\"25\"'),
(3,'2024-05-25 14:54:13','2024-05-25 14:54:13',2,'currency_id','\"25\"'),
(4,'2024-05-25 14:54:13','2024-05-25 14:54:13',3,'account_role','\"savingAsset\"'),
(5,'2024-05-25 14:54:13','2024-05-25 14:54:13',3,'currency_id','\"25\"'),
(6,'2024-05-25 14:54:13','2024-05-25 14:54:13',4,'currency_id','\"25\"'),
(7,'2024-05-25 14:54:13','2024-05-25 14:54:13',5,'account_role','\"cashWalletAsset\"'),
(8,'2024-05-25 14:54:13','2024-05-25 14:54:13',5,'currency_id','\"25\"'),
(9,'2024-05-25 14:54:21','2024-05-25 14:54:21',6,'currency_id','\"25\"'),
(11,'2024-05-25 14:57:26','2024-05-25 14:57:26',8,'include_net_worth','\"0\"'),
(12,'2024-05-25 15:04:15','2024-05-25 15:04:15',9,'include_net_worth','\"0\"'),
(13,'2024-05-31 14:09:25','2024-05-31 14:09:25',10,'include_net_worth','\"0\"'),
(14,'2024-06-03 14:42:59','2024-06-03 14:42:59',11,'include_net_worth','\"0\"'),
(15,'2024-06-05 21:29:14','2024-06-05 21:29:14',12,'currency_id','\"25\"'),
(16,'2024-06-05 21:29:14','2024-06-05 21:29:14',12,'interest_period','\"daily\"'),
(17,'2024-06-05 21:29:14','2024-06-05 21:29:14',12,'include_net_worth','\"1\"'),
(18,'2024-06-05 21:29:14','2024-06-05 21:29:14',12,'liability_direction','\"debit\"'),
(19,'2024-06-05 21:29:14','2024-06-05 21:29:14',13,'currency_id','\"25\"'),
(20,'2024-06-05 21:29:14','2024-06-05 21:29:14',14,'currency_id','\"25\"'),
(21,'2024-06-05 21:29:14','2024-06-05 21:29:14',12,'start_of_debt','\"-674.490000000000\"'),
(22,'2024-06-05 21:29:14','2024-06-05 21:29:14',12,'current_debt','\"674.490000000000\"'),
(23,'2024-06-05 21:34:11','2024-06-05 21:34:11',15,'currency_id','\"25\"'),
(24,'2024-06-05 21:34:11','2024-06-05 21:34:11',15,'interest_period','\"daily\"'),
(25,'2024-06-05 21:34:11','2024-06-05 21:34:11',15,'include_net_worth','\"1\"'),
(26,'2024-06-05 21:34:11','2024-06-05 21:34:11',15,'liability_direction','\"debit\"'),
(27,'2024-06-05 21:34:11','2024-06-05 21:34:11',16,'currency_id','\"25\"'),
(28,'2024-06-05 21:34:11','2024-06-05 21:34:11',17,'currency_id','\"25\"'),
(29,'2024-06-05 21:34:11','2024-06-05 21:34:11',15,'start_of_debt','\"-3081.000000000000\"'),
(30,'2024-06-05 21:34:11','2024-06-05 21:34:11',15,'current_debt','\"3081.000000000000\"');
/*!40000 ALTER TABLE `account_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_types`
--

DROP TABLE IF EXISTS `account_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_types_type_unique` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=248 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_types`
--

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
INSERT INTO `account_types` VALUES
(1,'2024-05-25 14:51:01','2024-05-25 14:51:01','Default account'),
(2,'2024-05-25 14:51:01','2024-05-25 14:51:01','Cash account'),
(3,'2024-05-25 14:51:01','2024-05-25 14:51:01','Asset account'),
(4,'2024-05-25 14:51:01','2024-05-25 14:51:01','Expense account'),
(5,'2024-05-25 14:51:01','2024-05-25 14:51:01','Revenue account'),
(6,'2024-05-25 14:51:01','2024-05-25 14:51:01','Initial balance account'),
(7,'2024-05-25 14:51:01','2024-05-25 14:51:01','Beneficiary account'),
(8,'2024-05-25 14:51:01','2024-05-25 14:51:01','Import account'),
(9,'2024-05-25 14:51:01','2024-05-25 14:51:01','Loan'),
(10,'2024-05-25 14:51:01','2024-05-25 14:51:01','Reconciliation account'),
(11,'2024-05-25 14:51:01','2024-05-25 14:51:01','Debt'),
(12,'2024-05-25 14:51:01','2024-05-25 14:51:01','Mortgage'),
(13,'2024-05-25 14:51:01','2024-05-25 14:51:01','Liability credit account');
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `account_type_id` int(10) unsigned NOT NULL,
  `name` varchar(1024) NOT NULL,
  `virtual_balance` decimal(32,12) DEFAULT NULL,
  `iban` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `encrypted` tinyint(1) NOT NULL DEFAULT 0,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `accounts_user_id_index` (`user_id`),
  KEY `accounts_user_group_id_index` (`user_group_id`),
  KEY `accounts_account_type_id_index` (`account_type_id`),
  CONSTRAINT `accounts_account_type_id_foreign` FOREIGN KEY (`account_type_id`) REFERENCES `account_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `accounts_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES
(1,'2024-05-25 14:54:13','2024-05-25 14:54:21',NULL,1,1,3,'Maya',0.000000000000,NULL,1,0,1),
(2,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,1,1,6,'Initial balance for \"Maya\"',NULL,NULL,1,0,0),
(3,'2024-05-25 14:54:13','2024-05-25 14:54:21',NULL,1,1,3,'Maya savings account',0.000000000000,NULL,1,0,2),
(4,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,1,1,6,'Initial balance for \"Maya savings account\"',NULL,NULL,1,0,0),
(5,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,1,1,3,'Cash wallet',0.000000000000,NULL,1,0,3),
(6,'2024-05-25 14:54:21','2024-05-25 14:54:21',NULL,1,1,2,'Cash account',NULL,NULL,1,0,0),
(7,'2024-05-25 14:55:31','2024-05-25 14:55:51','2024-05-25 14:55:51',1,1,4,'Family Financial Help',NULL,NULL,1,0,0),
(8,'2024-05-25 14:57:26','2024-05-25 14:57:26',NULL,1,1,4,'Financial Help in the House',NULL,NULL,1,0,0),
(9,'2024-05-25 15:04:15','2024-05-25 15:04:15',NULL,1,1,4,'Personal Expense',NULL,NULL,1,0,0),
(10,'2024-05-31 14:09:25','2024-05-31 14:09:25',NULL,1,1,5,'Raya Solutions',NULL,NULL,1,0,0),
(11,'2024-06-03 14:42:59','2024-06-03 14:42:59',NULL,1,1,5,'Return Borrowed Money',NULL,NULL,1,0,0),
(12,'2024-06-05 21:29:14','2024-06-05 21:34:33',NULL,1,1,11,'Shopeepay - Logitech K380',0.000000000000,'',1,0,1),
(13,'2024-06-05 21:29:14','2024-06-05 21:29:14',NULL,1,1,6,'Initial balance for \"Shopeepay\"',NULL,NULL,1,0,0),
(14,'2024-06-05 21:29:14','2024-06-05 21:29:14',NULL,1,1,13,'Liability credit for \"Shopeepay\"',NULL,NULL,1,0,0),
(15,'2024-06-05 21:34:11','2024-06-05 21:34:14',NULL,1,1,11,'Shopeepay - Lexar NM710',NULL,NULL,1,0,2),
(16,'2024-06-05 21:34:11','2024-06-05 21:34:11',NULL,1,1,6,'Initial balance for \"Shopeepay - Lexar NM710\"',NULL,NULL,1,0,0),
(17,'2024-06-05 21:34:11','2024-06-05 21:34:11',NULL,1,1,13,'Liability credit for \"Shopeepay - Lexar NM710\"',NULL,NULL,1,0,0);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `attachable_id` int(10) unsigned NOT NULL,
  `attachable_type` varchar(255) NOT NULL,
  `md5` varchar(128) NOT NULL,
  `filename` varchar(1024) NOT NULL,
  `title` varchar(1024) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `mime` varchar(1024) NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `uploaded` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `attachments_user_id_foreign` (`user_id`),
  KEY `attachments_to_ugi` (`user_group_id`),
  CONSTRAINT `attachments_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `attachments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log_entries`
--

DROP TABLE IF EXISTS `audit_log_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_log_entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `auditable_id` int(10) unsigned NOT NULL,
  `auditable_type` varchar(191) NOT NULL,
  `changer_id` int(10) unsigned NOT NULL,
  `changer_type` varchar(191) NOT NULL,
  `action` varchar(255) NOT NULL,
  `before` text DEFAULT NULL,
  `after` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log_entries`
--

LOCK TABLES `audit_log_entries` WRITE;
/*!40000 ALTER TABLE `audit_log_entries` DISABLE KEYS */;
INSERT INTO `audit_log_entries` VALUES
(1,'2024-05-25 15:07:06','2024-05-25 15:07:06',NULL,4,'FireflyIII\\Models\\TransactionGroup',1,'FireflyIII\\User','update_group_title','\"Cetaphil Foaming Cleanser\"','\"Facial Care Refill\"'),
(2,'2024-05-25 15:14:19','2024-05-25 15:14:19',NULL,4,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-05-25T15:04:00+08:00\"','\"2024-05-15T15:20:00+08:00\"'),
(3,'2024-05-25 15:14:19','2024-05-25 15:14:19',NULL,5,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-05-25T15:04:00+08:00\"','\"2024-05-15T15:20:00+08:00\"'),
(4,'2024-05-25 15:15:18','2024-05-25 15:15:18',NULL,6,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-05-25T15:07:00+08:00\"','\"2024-05-17T22:22:00+08:00\"'),
(5,'2024-05-25 15:16:13','2024-05-25 15:16:13',NULL,8,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-05-25T15:09:00+08:00\"','\"2024-05-16T18:08:00+08:00\"'),
(6,'2024-05-25 15:17:20','2024-05-25 15:17:20',NULL,7,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-05-25T15:08:00+08:00\"','\"2024-05-16T18:08:00+08:00\"'),
(7,'2024-06-03 14:41:04','2024-06-03 14:41:04',NULL,22,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-06-03T14:39:00+08:00\"','\"2024-06-02T14:39:00+08:00\"'),
(8,'2024-06-03 14:41:21','2024-06-03 14:41:21',NULL,23,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-06-03T14:40:00+08:00\"','\"2024-06-02T14:40:00+08:00\"'),
(9,'2024-06-05 21:25:58','2024-06-05 21:25:58',NULL,31,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-06-05T21:23:00+08:00\"','\"2024-06-05T21:03:00+08:00\"'),
(10,'2024-06-06 23:37:49','2024-06-06 23:37:49',NULL,38,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-06-06T23:32:00+08:00\"','\"2024-06-06T21:37:00+08:00\"'),
(11,'2024-06-07 22:28:39','2024-06-07 22:28:39',NULL,43,'FireflyIII\\Models\\TransactionGroup',1,'FireflyIII\\User','update_group_title',NULL,'\"Starbucks\"'),
(12,'2024-06-07 22:35:45','2024-06-07 22:35:45',NULL,49,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-06-07T22:29:00+08:00\"','\"2024-06-07T17:14:00+08:00\"'),
(13,'2024-06-07 22:36:03','2024-06-07 22:36:03',NULL,46,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-06-07T22:23:00+08:00\"','\"2024-06-07T16:00:00+08:00\"'),
(14,'2024-06-07 22:36:28','2024-06-07 22:36:28',NULL,48,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-06-07T22:29:00+08:00\"','\"2024-06-07T17:11:00+08:00\"'),
(15,'2024-06-07 22:37:13','2024-06-07 22:37:13',NULL,42,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-06-07T22:12:00+08:00\"','\"2024-06-07T21:10:00+08:00\"'),
(16,'2024-06-07 22:37:21','2024-06-07 22:37:21',NULL,42,'FireflyIII\\Models\\TransactionJournal',1,'FireflyIII\\User','update_date','\"2024-06-07T21:10:00+08:00\"','\"2024-06-07T09:10:00+08:00\"');
/*!40000 ALTER TABLE `audit_log_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_budgets`
--

DROP TABLE IF EXISTS `auto_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_budgets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `budget_id` int(10) unsigned NOT NULL,
  `transaction_currency_id` int(10) unsigned NOT NULL,
  `auto_budget_type` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `amount` decimal(32,12) NOT NULL,
  `period` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auto_budgets_transaction_currency_id_foreign` (`transaction_currency_id`),
  KEY `auto_budgets_budget_id_foreign` (`budget_id`),
  CONSTRAINT `auto_budgets_budget_id_foreign` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auto_budgets_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_budgets`
--

LOCK TABLES `auto_budgets` WRITE;
/*!40000 ALTER TABLE `auto_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `available_budgets`
--

DROP TABLE IF EXISTS `available_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `available_budgets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `transaction_currency_id` int(10) unsigned NOT NULL,
  `amount` decimal(32,12) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `available_budgets_transaction_currency_id_foreign` (`transaction_currency_id`),
  KEY `available_budgets_user_id_foreign` (`user_id`),
  KEY `available_budgets_to_ugi` (`user_group_id`),
  CONSTRAINT `available_budgets_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `available_budgets_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `available_budgets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `available_budgets`
--

LOCK TABLES `available_budgets` WRITE;
/*!40000 ALTER TABLE `available_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `available_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `transaction_currency_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(1024) NOT NULL,
  `match` varchar(1024) NOT NULL,
  `amount_min` decimal(32,12) NOT NULL,
  `amount_max` decimal(32,12) NOT NULL,
  `date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `extension_date` date DEFAULT NULL,
  `repeat_freq` varchar(30) NOT NULL,
  `skip` smallint(5) unsigned NOT NULL DEFAULT 0,
  `automatch` tinyint(1) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `name_encrypted` tinyint(1) NOT NULL DEFAULT 0,
  `match_encrypted` tinyint(1) NOT NULL DEFAULT 0,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `bills_user_id_foreign` (`user_id`),
  KEY `bills_transaction_currency_id_foreign` (`transaction_currency_id`),
  KEY `bills_to_ugi` (`user_group_id`),
  CONSTRAINT `bills_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `bills_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budget_limits`
--

DROP TABLE IF EXISTS `budget_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `budget_limits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `budget_id` int(10) unsigned NOT NULL,
  `transaction_currency_id` int(10) unsigned DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `amount` decimal(32,12) NOT NULL,
  `period` varchar(12) DEFAULT NULL,
  `generated` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `budget_limits_budget_id_foreign` (`budget_id`),
  KEY `budget_limits_transaction_currency_id_foreign` (`transaction_currency_id`),
  CONSTRAINT `budget_limits_budget_id_foreign` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `budget_limits_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budget_limits`
--

LOCK TABLES `budget_limits` WRITE;
/*!40000 ALTER TABLE `budget_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `budget_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budget_transaction`
--

DROP TABLE IF EXISTS `budget_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `budget_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `budget_id` int(10) unsigned NOT NULL,
  `transaction_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `budget_transaction_budget_id_foreign` (`budget_id`),
  KEY `budget_transaction_transaction_id_foreign` (`transaction_id`),
  CONSTRAINT `budget_transaction_budget_id_foreign` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `budget_transaction_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budget_transaction`
--

LOCK TABLES `budget_transaction` WRITE;
/*!40000 ALTER TABLE `budget_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `budget_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budget_transaction_journal`
--

DROP TABLE IF EXISTS `budget_transaction_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `budget_transaction_journal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `budget_id` int(10) unsigned NOT NULL,
  `budget_limit_id` int(10) unsigned DEFAULT NULL,
  `transaction_journal_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `budget_transaction_journal_budget_id_foreign` (`budget_id`),
  KEY `budget_transaction_journal_transaction_journal_id_foreign` (`transaction_journal_id`),
  KEY `budget_id_foreign` (`budget_limit_id`),
  CONSTRAINT `budget_id_foreign` FOREIGN KEY (`budget_limit_id`) REFERENCES `budget_limits` (`id`) ON DELETE SET NULL,
  CONSTRAINT `budget_transaction_journal_budget_id_foreign` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `budget_transaction_journal_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budget_transaction_journal`
--

LOCK TABLES `budget_transaction_journal` WRITE;
/*!40000 ALTER TABLE `budget_transaction_journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `budget_transaction_journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budgets`
--

DROP TABLE IF EXISTS `budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `budgets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(1024) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `encrypted` tinyint(1) NOT NULL DEFAULT 0,
  `order` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `budgets_user_id_index` (`user_id`),
  KEY `budgets_user_group_id_index` (`user_group_id`),
  CONSTRAINT `budgets_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `budgets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budgets`
--

LOCK TABLES `budgets` WRITE;
/*!40000 ALTER TABLE `budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(1024) NOT NULL,
  `encrypted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `categories_user_id_index` (`user_id`),
  KEY `categories_user_group_id_index` (`user_group_id`),
  CONSTRAINT `categories_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'2024-05-25 15:05:50','2024-05-25 15:05:50',NULL,1,1,'Facial Care',0),
(2,'2024-05-25 15:09:17','2024-05-25 15:09:17',NULL,1,1,'Lazada',0),
(3,'2024-05-25 15:13:21','2024-05-25 15:13:21',NULL,1,1,'Financial Help',0),
(4,'2024-05-31 14:06:48','2024-05-31 14:06:48',NULL,1,1,'Fitness Equipment',0),
(5,'2024-05-31 23:20:07','2024-05-31 23:20:07',NULL,1,1,'Family Treat',0),
(6,'2024-06-03 14:36:05','2024-06-03 14:36:05',NULL,1,1,'Clothing',0),
(7,'2024-06-03 14:39:56','2024-06-07 22:15:55',NULL,1,1,'Public Transpo Fare',0),
(8,'2024-06-05 21:22:54','2024-06-05 21:22:54',NULL,1,1,'Drinks/Snacks',0),
(9,'2024-06-05 21:25:16','2024-06-05 21:25:16',NULL,1,1,'Shopee',0);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_transaction`
--

DROP TABLE IF EXISTS `category_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `transaction_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_transaction_category_id_foreign` (`category_id`),
  KEY `category_transaction_transaction_id_foreign` (`transaction_id`),
  CONSTRAINT `category_transaction_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_transaction_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_transaction`
--

LOCK TABLES `category_transaction` WRITE;
/*!40000 ALTER TABLE `category_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_transaction_journal`
--

DROP TABLE IF EXISTS `category_transaction_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_transaction_journal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `transaction_journal_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_transaction_journal_category_id_foreign` (`category_id`),
  KEY `category_transaction_journal_transaction_journal_id_index` (`transaction_journal_id`),
  CONSTRAINT `category_transaction_journal_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_transaction_journal_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_transaction_journal`
--

LOCK TABLES `category_transaction_journal` WRITE;
/*!40000 ALTER TABLE `category_transaction_journal` DISABLE KEYS */;
INSERT INTO `category_transaction_journal` VALUES
(1,1,4),
(2,1,5),
(3,2,7),
(4,3,11),
(5,4,12),
(6,3,16),
(7,5,18),
(8,6,20),
(9,7,22),
(10,8,29),
(11,9,31),
(12,3,38),
(13,8,44),
(14,8,47),
(15,6,49);
/*!40000 ALTER TABLE `category_transaction_journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` VALUES
(1,'2024-05-25 14:51:01','2024-05-25 14:51:02',NULL,'db_version','24'),
(2,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'is_decrypted_accounts','true'),
(3,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'is_decrypted_attachments','true'),
(4,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'is_decrypted_bills','true'),
(5,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'is_decrypted_budgets','true'),
(6,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'is_decrypted_categories','true'),
(7,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'is_decrypted_piggy_banks','true'),
(8,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'is_decrypted_preferences','true'),
(9,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'is_decrypted_tags','true'),
(10,'2024-05-25 14:51:01','2024-05-25 14:51:02',NULL,'is_decrypted_transaction_journals','true'),
(11,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'is_decrypted_transactions','true'),
(12,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'is_decrypted_journal_links','true'),
(13,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_transaction_identifier','true'),
(14,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_migrated_to_groups','true'),
(15,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_account_currencies','true'),
(16,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_transfer_currencies','true'),
(17,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_other_currencies','true'),
(18,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_migrate_notes','true'),
(19,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_migrate_attachments','true'),
(20,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_bills_to_rules','true'),
(21,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_bl_currency','true'),
(22,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_cc_liabilities','true'),
(23,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_back_to_journals','true'),
(24,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'480_rename_account_meta','true'),
(25,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'481_migrate_recurrence_meta','true'),
(26,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'500_migrate_tag_locations','true'),
(27,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'550_migrate_recurrence_type','true'),
(28,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'560_upgrade_liabilities','true'),
(29,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'600_upgrade_liabilities','true'),
(30,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'550_budget_limit_periods','true'),
(31,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'610_migrate_rule_actions','false'),
(32,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'oauth_private_key','\"eyJpdiI6IjdORTd5c25nc2pYWWdrb3lLbHk5WUE9PSIsInZhbHVlIjoiV3VHc21SMWg4TnBJRHNnWGxZZ3N5MjNwV3ptZW1BWExHdXdaSEkzZHE4QjJ0R1lpK2xmcDhKaTJ2TE1MMWpSNGN6a2pUMWo4NUtaUSsvamNwTHRva3d4MzhlMUZkaW9hL1dQZVBiZzluZnVLRERNRHlSS01KMkx6dFp5RjVZMEFvN0hCRzJIK3drWUhxNDUzamYvT3ZxS0szV0tUSXZpM0dLRXE2WVMva1JvT1lyaWJEemdxUnIzZmcwMjFUYTVkNmdBNXhlMzg5Ym1TdkRuNVMvc2VkOFpGSERvMmxqVzNERHFONGNjK3BwYTRzRHZZRTlFV0RQZzhHakFFR2NOZmN3Z2RxQXNMdi92bWdEQWd3MWs4cEk4STR4c3BHSjlXcGthWHB2N0lkZmVlMVFoMFNEbEU3VmJsemtiSm9ZTXlFRmpiRXhhT2dNSnJQRkxNdjZGOTZFZE9QWFRiT0s0cVFGc2xxdlZnYjFrdVRocVNXa29saTNrK3BsSk42dlNXU0lPOGFYWDFqbm8zdWhrSzBvV01KblFTeXpVL20wMnN3ZUhDWWM1QnA0Uk5Bb0M5QytYaERJWDdWdGNQRU9QS3plYWZnSTlPVE1ScGJLWW5YYnpBa0R1TGVrd01TdXp6TDFRcE4weUR6OENxQVBhM2lHaEhDaWhrTkJKY2UzVnVQeUx1bkl4NDc4T09LU0JQSFllaFpFc3RpY1IzV2FtRE1RUVduaEo0T0c2N1kwaEcxWldSUEUzWkFOY1JBaWpXNjdoUTNtenBzZXhjR2Y1K3FuY1QrUm0wYVBYQkJwMXhObTUrSHZPQVZKYmdPYmFiR01MdWljcjFnVThQWEdiM2ttYmptRFdNOVZJR3djNnMzV01LaDJkM1d5QVYvU0xHelNVK29xUEtsbFRFYktGcnA4UGVlVDZkK05wa0syQmN4N0NDV1phR01JVlVVTHhKK3FQTmJKam9FN1d3Rmg1Vk1lNjloK0MxNkNFcHhZWE0xZ3U0eEhzNVoyc3d2Zjk2ZDNuMnBUTk42dk1HOWswOFFHSVNJQ01iUldXMEs2TEtabERDU0gweWljNTVGVDJqNlYvL1BObUJVL3djdVJNUGFqZkF0UEdtSTJYVTN2LzRoSzFZRk5XUW1UMS9QK1RHYWpUdkRORnYzczRKa2ErT203Zy8vd3JOaGFRMzR1QURXcG1JeWhFRWU1S21PK2hkcWxCQWxSam1tOVFxQ0RMUHQ2d3BuWmJidDBWa2NBUlBUMDNnd01XaGtJSE1yVHNVbVpkTzlZcjBnUGhabnV0VTQ4R05UK3VxZ0NvUHFKVTFncEYxYzJHZW5KUjJENVJDbElHaG1LWjJ4M0J4V2tYTXJyd2JRVThDYng3N29vUGxrQjhYa2pGVFBhNnlpTkZrd292S3p2OXpreFRMeGl4ZUcyajlCTHhjR3ZqZGVsUUs2cHAySmlyN2xPM3E0SUIzNTBKbEZYYmxsWS9ITEZVREx2SVZtcS93T1FORXRTZkNtanRTRUJiQUhUbEtJeWU1bGVpK0lRcTBpMlNnSXdpUmpCNGhiYko0OWZHOXRSd1I2TFB4Y0xHWWZNTlZKY3lzdWI4ZGFGdHJLUEhKc2xFOUhPNURkc1BRZlVmbDFUNnBhMkJhdWRYeDAvcG1sc2JKNzMweGl4MFJHaWpZaStJRXJMdmRiOWsvZCtmeXlxbkNTb2tLUStPbnFwajZtZUtYcllQNnR3L1I5Q3o0b2o0R2ZDR1N4OFZXL0hoNGFCSmpFM2ZINVVsMTJZRmprVHRZR3p4L3krMW1YR1RpZ01SSFJpS2R5SDFPY0JhRW5pUm15UFFkalM3azdKL0FTK0hJR3FlMGlxZGZiUUowQzdSbFF6RHNjOXliMHlEN2Q2NDBxOWdMa2ZXeU1HMVRYdW1FWmFRemFMMVZ4SGo5Z2RNVExhVDNMNUpjWEQvN1FubDBBY1ZSdlVLMldZRmx6YlFrb3JVK0RQREYrNFErY0ZVb25VTnVnMmVhbjZCaFAyU0NJaHlGMnpFQmJQdDMrNS9lcnkwUjFoazhlNUd5b0ZYa1o1Nm5NLy9CYlY1L1RLZEQ1L09wWURneWVZT1psd1JFMWxxbWtiRDRrYjA2N2NBVFpuNVcrVVpxNGs4WnF4ak91dFRicERjZnllR1F5K3YxWndialp5YVVDTXF3RG9ucmNVYlY3RVI5TWRjWThDNDVPVTFUMDMwY2NQQkhudWxRT2lyaWN1OU84RGZHc3dWNDNBYlFYaHdNYStTQ2RXa2JuSnpLYlUyenRVeEVnZ3M2VEs3UmREL1RSRk50SER0amdxcDBxQWtpc20zVXdaUlA0eEFGVnBEaU5BanhkSjFUUzEydk9EaTFDdG1CeUNUODJHRjZlZVBkS0dGTnlDakc4cmVVODRYdEZZWG53dnJjQUZNYmJ1VXo2RVEyV21kak1RQTJ1UGdTTWpseWlmSnRFVmJzOXBMQUZlN3d4TW9VeFZLQlBNemJSUk5CQmlzbDhjWnErMlVyc0tJcFZTWHE0bnBNOTNDeFpBL09oUmt3WGRLYjZJKzdXRm05dnNZbk13VDRRVDRaOGZOVE4vdjNNWG91amNiaGpSM1pYa1RaK0lVMW1TZHBYc09TQSthYXlSSm1YejFCalphZnBVNVd6NGpoSXZXandlK05SaTdsc0Y0VWU1N0UzNy9JTk04L0F4OXdScVBwazVOZE1EK0R6UWtoY3pMY1V6ZVFNREcwWWIraE9aNEZ1c3lWN0VkYk5mNnBNSjllV2RQT1Fxa1Y5M3E1NSsrNUZoSSthWnVRVEVhN3ZqeVM2R05vTHI0TlRHOGZvL3czbG1UVVVQZ1BpN25peVBSM3owcFIrRmk4WTg2S045QkNSVmpHL1VlNWwwL211ZFlSTEMzZlZhVmVKaXV4c0lkRFAzM2ZndEtHcHBnTnBOQmtobUFkTWcwUmZtMmZUYytTK0ZpbXpNRXlDbHMrTWxFREtIaFhUMTloMXUwNjBzbUZ0cC9mbWxhTCs1aUV0d3JuUnBGRXJRekVnTVg0cjFEeGNiSDFvWExUb3BJTFBncksxK0lKWkcybzVObDl1YmxpakwxNGhGT1FlVEFGK1JiRDBoaGh4SXM3dWRxSXdEeHpPU3FKbS9ZUjdZUGFLTVN2TGxQMEhRd2E4TTNWdHR3eXMrdWRKSlllS1BPblpmZjZwSk11L1BKVDJCTWdQeGREWHFNQ3lzcFFPVElJdEJLVkUzQkY4cE1XcWtXUm1vZ1dkUjhqQWN3bjNXTzRkay81SjhDK2QzeXVDNTFrejBQN0ROWFJ6bUNYcjFNUGwzS2YwNUMxSXhudGpiTllORThrdUJRUHRpTngvYk1lc1RuTzRMYWg0cEE5L1c0WXllMmVLekdweGF4ckVPdXQ5Y3loQ2VMa0c4dm1wZml2QUZiV3FSVjY5cW95NnI1OTFrOTJSOU5NeXI2NUZRVktyT0FmSnRFRjF6Yjl0MEdqOGx6V3d2djBoTVJxTDI5ZmltOXBRTEtUU3JEL2RwZGUrcksxQks5a2VsdGVJdnB0MlZwNXdUNktWckFDQ1NtR3I0NmxwZUNZWlRMazloSkE0RUJsdGVKOFRnRk5RSERmVjIzTUkvVkkyNU1Kbm81ZnJlWkkwcWlpd0sxRHl0NncvWS96V2wrQ01JMWVGWVBlbjFqK0ozWXEwbUxxUExxKzVDTUZWTnRQWElCYnlaUEk4UU1mN1JrMysvWkp5eVJJcVBQYzdnd1FlMmw1em5tTGdCbnJpL3M3L2UyMEFYRWVlWDBFQXhTZzBtMjM2M1FQb3hhc0JCU3NGQ3JKUndmbmJTb2xRZnBVVmc1MWYvQ2lIbUt0OGozZzhjd28rYi9DaDBFbEFUdmhLN0o3dTVMTW1zTzdQN1VrRTR2Q1AycTRvR0RWOTcwZXdKSzAwNGpxRGJhM2dLcjNkVFNidnlJMjkyckxUL0hHeUhPanNoNWhieFdTbDZOdktLVW4wVHFCUTM2MEJId2h1dzYvcTl5K2tVbVpmdGxQQVdkT1NaY1NsUG9PTWRWUEx3dmpJRmNCNXJvTU1lSXNnbXB5QitnZkNXdnpiaUMvNDBDOTYyWGNjZXI2WTZCdDdqTGsxK0Q4UU5QQmFqREt1bGw2YkRkVkJTWlU1VUpZVncxeG5BUlF5RkJVRE5kdGNaZytIZURqdi9yekl3U0k2THhONk1QMTN2emgzbjlPSC9CNWJtVjFad2swcTloN2FRMldCUzhqTm1GaTNkaDNxdElvVXQ5dFVtQ2pBSFl5ZFlDZ2l6TFppTkw4R284bDAxTXFLK2NSM1Y2aFVIL3VPN2szd2xaeGdNU3V4MS9nd3hPaDYvZThqRGpocUkrN2c4U1dOcXJsQmdOSXN6bE5Za3h3Yjc4eGQ4RUR3MzFDOTlSZFpSaVRaOU9ncEE1amJ6NjdoSU5hRXYwS2EyejZ3TjBuOVA1dlY4Mk8wRXgvc0d4clFxSmtySk9VWGszU0pldklLUktlRk96VitBWVZpcnI5MjdBYVVCRGc5M01wY1VOVkFvSHdKT3ZZRzZIMzlRVWlTSGN5ZVY4Tmc1R2lGR0hzNDhGS3pPU2lleVRGV3gwYTZuS2VycS9yUDFqTmVOZVRjdGFISVJQTzhSK04vd3lwTjdPRTM2bkxkb0pPLzZ0ckhSWHhmdGJUekJHUmlRdXBieWtEL0thajBFSUo4amN0K21vd05td2R2MmVBMXRtdGlUd2VaZllxaDFYMDJaU2tKWENEQ1p6ektUb0wyUkdKUUpiUTU1Wno3RUFHY04xVFVTL3RuM1hkSzQzV3ozOXViZlV3TVJKMkxRN1VWdFIybVhXeVNRWGRMUG5LbTUvMmhGcE0zeDVFekhhcU1JVk9hSXlNbDBPSlBPTVFkd1dqb2xhTVRLcWdhS1hld3o0NHlzU2tLN1VHUzRLWDIvUlRLUGUrRWxlSjZ2UCtwSUp6emIzYnFha2NOekd0VmlJZVJnZU1WQWdWT3hQdnc3ZEVGSWFOS3B5dDB2VytkcitGQ0t2TzA0VUpUNytXcW52aCsyeEk2NU9HUUg0cjl4L2wzUVhCMnU5NnhVa3lYVzZ3QnEvQytTNUF5dzV0em5kbEt5bllGNGVJTzBKM3dpczlJSHlxY2MzbFQ4NU1yN00zZFM5bmlZdzl5T2xIMWY4RmQ5NmZDdEVrbU9Qbjh4Z3Y2NHhzMHJ0YmIrNkthdUYrTUQ0Z0x4SFdYeFY0dGovem0zMDIzMVpVTTMzd1dxaE5HQkVIRWNwSDZxNC9rUTJ5Q0paVHZtOEN3dWpJYWsxaElzS3haRzk3Y0FBUkVtemZuMVU1Wi92UXRUUE5WZWdTUVIyU0QwQ3NSSnJOOHFJbWJkdEhMbjIvQU5uVVBzZGNzdjZwcWpsME16TzBVYjdaaG9wWXNLN0hvdm15L2hwZytwSTJuOWJaeDlFTWp4Z3E2UTE0b0s1V0FTSVU4RXpuMHlmTEVJTjFnOHdzazIvcVdKTno5eEJhcWlIMlJvcFNRNEtzcGNwTy9mQ0prS2lxNkpDVk1TVk54NkhyMnVNNW5MWUMvc1dFR3F4RFNyMWR0eXVkV3FrNGdnbVRUc3BndnllRkI1VHVtNzJ2cG9BODN3Vk9yVXJwOGdGU3VOVTRGMnh0c2tJd0JTRDhDNDNFdnRreldRR0xmUHVGa2VvSnE3bW0vUnRHRlY0TUxCT3gwcXhUSmFQQXc4M0NhMU1vajlWQVBuMTFaeGVrUjY1UlR1NXNOYUVrY1VJekdnc1FGcDROdGVFcDhYTXJRWHBhbWEweTFrdS9mSzJJSTdSYng1WVAvbFJDY3NKSGpSeURJTG8yUXY0UlIyNytEeVRZaGs5YnE0SmdTdkMybGFPcktNU1RCT1dEVUdXY1U1VGNPeFNNS25kYWE0VT0iLCJtYWMiOiI2MmYxNDMyMDAxNzk5OTBmZDVkMmViZGEzMzYxMDFkNTlmMDc1MGQ0YWRjMDNiNGY1OTc3YjZmYzQ5MzQzYWY2IiwidGFnIjoiIn0=\"'),
(33,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'oauth_public_key','\"eyJpdiI6IkFPV3Z3K0FiMHdZbEh2K2FKWTVMTmc9PSIsInZhbHVlIjoiK3ZKTFgvdXphQzVxQlEyVXVobFhKL3d0MmpnT1MrV2xnZjBqTDUwdU1aOVBaVklBaFI4VFU3SWZjWS9HdmtrK2o4ckEwS1FEcjdqeTd2WUdobG1PYjlOdm5sWW9pZi9JYjFFajNJM2lkNFZYR09ubnR1YTJpZzFJQWhIQStwSE5rTlo3Yit4VU9NOEhDR09QOHQ5a2FaTVBJTUNwZWd1SHg4RjJ2cGpnZTZ4MDFZditRMEtNRVNSL1N2cUFiYVZrV3c5ZTc2RWR3VjJFYnN3OHRUaFVuOTFjQllWVTQ4cVZNdGJzSUV5VmZoYnpHTWVvWEdDaGZDSzN4b3FwR1FzRDBDc3AxV3JMNmtzUzRMeXBtcTg5NjA4UU1xQ1JoYVltZ1M4SDZ4MzRHRllkam1hclNnR29hUWpFODlnSE9GN3FqUHJWdkNxL1FPYUNLRzdPblZ3VDBTKzJrVXY0allBUXh0RFp6L1RKbUNGa2t6N2xTaldKQU9JMzVOd0hIeUhwbTdHSTZjd094QUxDMFo3eXBLMXV2WU9pSGh5dVl5S0hDdFduWFpIaWJrWWhkU0gvdmNsOGRSclBNNmpNa2V2bWZvZXhXeUNsWFpFc2laWGMxT2RxdlVlTnRHbWFoQ2FjeEdPQ09tNTNESEZManA1dXExRWIvVndUUld0THpEdlFjQU9FQlc5Mk1ickVNbkRNY2RsbXNiN1Q4V1JhRGZmdmllVitIelJGRDVOWjNsaFNEeGtDeEY1VEtxNU9SV3QzaE9STDV5RUV5S1o4U0Vzem1kdlJUZmRITlVLZnc3elREQTFKWTNwcTFQK2xEb3BwTU5qenlmNVJxc29nQzliVndzTlI0dDc3WTB0VnlsWmV2cnArb1pBWE9haGprKzZPcFJWVTJUa21SY2FQNGZML2E4OEpLQUhsUmZPREZsVkwwMTVRd3gxR2txbHRDZGdCYTBvUUhidDNGdGw0aXY3emFyRW85Z213RjV3S2FFZFZQdFJEc1dYc1NDU2xUaCtLZzYrN2xCZDJSeGtJOHlDS3lhMVB3V3l1WGFrRHRLWUZhR295US8wdkc5U3JiRnY0QzUrTVVhZVVQZmFTRzZuNmszT2diWTJXbVQ2NGJMQkU2dVZJUWwvZkFEa29tOTVFVTh5a1g3QzlqMjVDOXJ4QW9iNWx0NkxPN0d2bGN0T2FaVHk1SXQvRHpiRkFDZWlFck9GczBQUlBQTUViUTkrVW03RVF3SmZad2QzV25tUVdiMWU0UElzbVRxMzZraFR6ekQwT0gyMlk5NVF4SHdsWHNZRVRUZmVIb0NPaUhtaTh3ZVJCc0E1Z1UrZytJSnBxZ3J3d0Jwc1MvczFjM2FDNFZTOUZZenBwbHA0WFZHS2NaTFlHMGtRZ29OLzlGKzMwQlV4NXpDVkdmczEra1JTREZCK1ZVdTgxZ2xSbVNKczk2MUNQSEUvMi9XWE44ZWNvdnVsMzFnPT0iLCJtYWMiOiJmN2Q3YTQ3MWU1OWQ4ZWZiNjY2ZTE4NTFlYzMxNzgxYWFhNmY0NTMzZjg4NGM4MGIxNDBjNDNmN2I3Mzk1ZDZkIiwidGFnIjoiIn0=\"'),
(34,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'610_upgrade_currency_prefs','true'),
(35,'2024-05-25 14:51:02','2024-05-25 14:51:02',NULL,'ff3_version','\"6.1.16\"'),
(36,'2024-05-25 14:51:03','2024-05-25 14:51:03',NULL,'installation_id','\"9f1c8d2d-af9d-4a0b-b6fe-38d5dcb67034\"'),
(37,'2024-05-25 14:51:13','2024-05-25 14:51:13',NULL,'is_demo_site','false'),
(38,'2024-05-25 14:51:14','2024-05-25 14:51:14',NULL,'single_user_mode','true'),
(39,'2024-05-25 14:51:59','2024-05-25 14:51:59',NULL,'notification_user_new_reg','true'),
(40,'2024-05-25 14:51:59','2024-05-25 14:51:59',NULL,'notification_admin_new_reg','true'),
(41,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,'permission_update_check','-1'),
(42,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,'last_update_warning','1716620053'),
(43,'2024-05-31 14:17:40','2024-05-31 14:17:40',NULL,'notification_new_version','true'),
(44,'2024-05-31 14:17:40','2024-05-31 14:17:40',NULL,'notification_invite_created','true'),
(45,'2024-05-31 14:17:40','2024-05-31 14:17:40',NULL,'notification_invite_redeemed','true'),
(46,'2024-05-31 14:17:40','2024-05-31 14:17:40',NULL,'slack_webhook_url','\"\"');
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_exchange_rates`
--

DROP TABLE IF EXISTS `currency_exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency_exchange_rates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `from_currency_id` int(10) unsigned NOT NULL,
  `to_currency_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `rate` decimal(32,12) NOT NULL,
  `user_rate` decimal(32,12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency_exchange_rates_user_id_foreign` (`user_id`),
  KEY `currency_exchange_rates_from_currency_id_foreign` (`from_currency_id`),
  KEY `currency_exchange_rates_to_currency_id_foreign` (`to_currency_id`),
  KEY `cer_to_ugi` (`user_group_id`),
  CONSTRAINT `cer_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `currency_exchange_rates_from_currency_id_foreign` FOREIGN KEY (`from_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `currency_exchange_rates_to_currency_id_foreign` FOREIGN KEY (`to_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `currency_exchange_rates_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_exchange_rates`
--

LOCK TABLES `currency_exchange_rates` WRITE;
/*!40000 ALTER TABLE `currency_exchange_rates` DISABLE KEYS */;
INSERT INTO `currency_exchange_rates` VALUES
(1,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,1,'2022-06-06',1.000000000000,NULL),
(2,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,2,'2022-06-06',387.962900000000,NULL),
(3,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,3,'2022-06-06',0.854207540000,NULL),
(4,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,4,'2022-06-06',31.659752000000,NULL),
(5,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,5,'2022-06-06',4.581788000000,NULL),
(6,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,6,'2022-06-06',17.801397000000,NULL),
(7,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,7,'2022-06-06',7.438975300000,NULL),
(8,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,8,'2022-06-06',1.072228100000,NULL),
(9,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,9,'2022-06-06',5.097317300000,NULL),
(10,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,10,'2022-06-06',1.345996900000,NULL),
(11,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,11,'2022-06-06',20.899824000000,NULL),
(12,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,12,'2022-06-06',15466.299000000000,NULL),
(13,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,13,'2022-06-06',1.483854900000,NULL),
(14,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,14,'2022-06-06',1.642582900000,NULL),
(15,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,15,'2022-06-06',19.997350000000,NULL),
(16,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,16,'2022-06-06',10.573307000000,NULL),
(17,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,17,'2022-06-06',16.413167000000,NULL),
(18,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,18,'2022-06-06',140.152570000000,NULL),
(19,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,19,'2022-06-06',1.000000000000,NULL),
(20,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,20,'2022-06-06',66.000895000000,NULL),
(21,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,21,'2022-06-06',83.220481000000,NULL),
(22,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,22,'2022-06-06',3.571250800000,NULL),
(23,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,23,'2022-06-06',1.032389100000,NULL),
(24,'2024-05-25 14:51:59','2024-05-26 13:04:53',NULL,1,1,1,24,'2022-06-06',7.522084500000,NULL);
/*!40000 ALTER TABLE `currency_exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_journals`
--

DROP TABLE IF EXISTS `group_journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_journals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_group_id` int(10) unsigned NOT NULL,
  `transaction_journal_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_in_group` (`transaction_group_id`,`transaction_journal_id`),
  KEY `group_journals_transaction_journal_id_foreign` (`transaction_journal_id`),
  CONSTRAINT `group_journals_transaction_group_id_foreign` FOREIGN KEY (`transaction_group_id`) REFERENCES `transaction_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_journals_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_journals`
--

LOCK TABLES `group_journals` WRITE;
/*!40000 ALTER TABLE `group_journals` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_memberships`
--

DROP TABLE IF EXISTS `group_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_memberships` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned NOT NULL,
  `user_role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_memberships_user_id_user_group_id_user_role_id_unique` (`user_id`,`user_group_id`,`user_role_id`),
  KEY `group_memberships_user_group_id_foreign` (`user_group_id`),
  KEY `group_memberships_user_role_id_foreign` (`user_role_id`),
  CONSTRAINT `group_memberships_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `group_memberships_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `group_memberships_user_role_id_foreign` FOREIGN KEY (`user_role_id`) REFERENCES `user_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_memberships`
--

LOCK TABLES `group_memberships` WRITE;
/*!40000 ALTER TABLE `group_memberships` DISABLE KEYS */;
INSERT INTO `group_memberships` VALUES
(1,'2024-05-25 14:51:59','2024-05-25 14:51:59',NULL,1,1,14);
/*!40000 ALTER TABLE `group_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invited_users`
--

DROP TABLE IF EXISTS `invited_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invited_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `email` varchar(255) NOT NULL,
  `invite_code` varchar(64) NOT NULL,
  `expires` datetime NOT NULL,
  `redeemed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invited_users_user_id_foreign` (`user_id`),
  CONSTRAINT `invited_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invited_users`
--

LOCK TABLES `invited_users` WRITE;
/*!40000 ALTER TABLE `invited_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `invited_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_links`
--

DROP TABLE IF EXISTS `journal_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `link_type_id` int(10) unsigned NOT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `destination_id` int(10) unsigned NOT NULL,
  `comment` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `journal_links_link_type_id_source_id_destination_id_unique` (`link_type_id`,`source_id`,`destination_id`),
  KEY `journal_links_source_id_foreign` (`source_id`),
  KEY `journal_links_destination_id_foreign` (`destination_id`),
  CONSTRAINT `journal_links_destination_id_foreign` FOREIGN KEY (`destination_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `journal_links_link_type_id_foreign` FOREIGN KEY (`link_type_id`) REFERENCES `link_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `journal_links_source_id_foreign` FOREIGN KEY (`source_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_links`
--

LOCK TABLES `journal_links` WRITE;
/*!40000 ALTER TABLE `journal_links` DISABLE KEYS */;
INSERT INTO `journal_links` VALUES
(1,'2024-06-07 22:13:57','2024-06-07 22:13:57',1,42,38,NULL),
(4,'2024-06-07 22:26:30','2024-06-07 22:26:30',2,44,45,NULL),
(5,'2024-06-07 22:26:52','2024-06-07 22:26:52',2,44,46,NULL);
/*!40000 ALTER TABLE `journal_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_meta`
--

DROP TABLE IF EXISTS `journal_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `transaction_journal_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `hash` varchar(64) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `journal_meta_transaction_journal_id_index` (`transaction_journal_id`),
  KEY `journal_meta_data_index` (`data`(768)),
  KEY `journal_meta_name_index` (`name`),
  CONSTRAINT `journal_meta_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_meta`
--

LOCK TABLES `journal_meta` WRITE;
/*!40000 ALTER TABLE `journal_meta` DISABLE KEYS */;
INSERT INTO `journal_meta` VALUES
(1,'2024-05-25 14:54:13','2024-05-25 14:54:13',1,'import_hash_v2','\"d4ec35b2b391ce4a536e4c094e78b965c5bbbbb8a8aa1236a41af79b3da20c84\"','88366a90a79da84a55a56754d50370bccb350a9d8bdeb905a4ec83a2355a46f9',NULL),
(2,'2024-05-25 14:54:13','2024-05-25 14:54:13',2,'import_hash_v2','\"01db0585881a10b46b96a12769579e61d0709ef4c391231d890d896a33232474\"','84e584b48fe2b4972f407bc2129c15fa4f17005958b6c3240deef255551e9a5d',NULL),
(3,'2024-05-25 14:54:54','2024-05-25 14:54:54',3,'import_hash_v2','\"2f07cb0384b29d66d57c08c46335ff01e7555b076bf5f764a637d636e13614ef\"','90689c54ddfe3a410641da676313f76afd5b171a05ed544b3b008c34610f83c7',NULL),
(4,'2024-05-25 14:54:54','2024-05-25 14:54:54',3,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(5,'2024-05-25 15:05:50','2024-05-25 15:05:50',4,'import_hash_v2','\"022495160f6f59b1606c5d5ee0cd1073bdc36eb7a3529bc17eee74708cab4e35\"','7d472dcbb11ab1e115f4e0c86dc9908d02b1642285be16b8a6456aad72522b82',NULL),
(6,'2024-05-25 15:05:50','2024-05-25 15:05:50',4,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(7,'2024-05-25 15:05:50','2024-05-25 15:05:50',5,'import_hash_v2','\"6a72daaffa6812f24e59a27dfd4376ae290283c8863c56e077378dd392597bad\"','6b95a6454ca042163c6869bbfc044b64c850c347c7da75dd7d0fa5f96223bbdb',NULL),
(8,'2024-05-25 15:05:50','2024-05-25 15:05:50',5,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(9,'2024-05-25 15:08:21','2024-05-25 15:08:21',6,'import_hash_v2','\"d1ac6b89acc65def99a570d8804a07812f61337d54ac0332753cfbae348036d8\"','0cfd75e9893553c7158f750992d6d1a168252788dacd30620761bc79502d4494',NULL),
(10,'2024-05-25 15:08:21','2024-05-25 15:08:21',6,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(11,'2024-05-25 15:09:17','2024-05-25 15:09:17',7,'import_hash_v2','\"db81213fa0563d7d9ac00b38b34eb834702d29f8754bbd85cd3c1aa9825ba342\"','59ab57b8569826b1e9d5dcc67c72ee73297f803a3e015c56ac854ca036236853',NULL),
(12,'2024-05-25 15:09:17','2024-05-25 15:09:17',7,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(13,'2024-05-25 15:09:41','2024-05-25 15:09:41',8,'import_hash_v2','\"9e418989795238307422b4071c8eeda61b0878b16872dcb5c82842b697f428f5\"','203e6a4faa80d2e29fb732f19ea3f33850845d17cc24a0c9ec8ab64a847c5a7c',NULL),
(14,'2024-05-25 15:09:41','2024-05-25 15:09:41',8,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(15,'2024-05-25 15:11:08','2024-05-25 15:11:08',9,'import_hash_v2','\"0fb10bd0d40665415146090450c7c1ffe933979cd2fc0f6e4f6e8b90bc026244\"','334f8816e7f4395f8965e014f8feec6ed87cc95104bd6dee61492aa8990a79a2',NULL),
(16,'2024-05-25 15:11:08','2024-05-25 15:11:08',9,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(17,'2024-05-25 15:12:18','2024-05-25 15:12:18',10,'import_hash_v2','\"d206a9750ae12e25e7c2cc52129b00c2d62bfc30dd6201ca28e8fb436cd3c0bc\"','0b72fb553413a302782b6cd4b517492019b09c33036a4a600144eba94e70036e',NULL),
(18,'2024-05-25 15:12:18','2024-05-25 15:12:18',10,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(19,'2024-05-25 15:13:21','2024-05-25 15:13:21',11,'import_hash_v2','\"bf72c9435def631d48d59509c31a4c047430f5d4b2bfbb16dd7c863899bf05ce\"','e9c211dd712f04dc190d45a5ed423d978b65f5165aae6c7a447cba7e83df6c3c',NULL),
(20,'2024-05-25 15:13:21','2024-05-25 15:13:21',11,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(21,'2024-05-31 14:06:48','2024-05-31 14:06:48',12,'import_hash_v2','\"0bf8da6b7d3154b220f7088e48f02d0b7ec8782bb8c5ce3ed2ee36171cb26f42\"','736ae5ce96ddfb5b25f4ba878f9f1ca8a6fec67ac6e271b58661d0efb55c2010',NULL),
(22,'2024-05-31 14:06:48','2024-05-31 14:06:48',12,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(23,'2024-05-31 14:09:59','2024-05-31 14:09:59',13,'import_hash_v2','\"1fe29fc031db92310287f2dd470008143e580b435eb5ecc0a6f4c2049b50e462\"','1328f246a91be384e6a2fcf4f3911fc81cc9ff549190b7631d5a63ac28a62a14',NULL),
(24,'2024-05-31 14:09:59','2024-05-31 14:09:59',13,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(25,'2024-05-31 14:11:29','2024-05-31 14:11:29',14,'import_hash_v2','\"757fcb387808b49f2f84c3fe3d19fc8c14068a88f301fd4fb938678891cff710\"','4ffbbb2ebe5903ebd06acac93bb4cedd80563a4f0b5c100c4a77fd4e3d512336',NULL),
(26,'2024-05-31 14:11:29','2024-05-31 14:11:29',14,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(27,'2024-05-31 23:14:22','2024-05-31 23:14:22',15,'import_hash_v2','\"407ee357082820004881917e9bbd648137d838b48d0a803e981bfe610556e261\"','d0a46edb526d86454829eee2c81f289004226953e7d8cceea01303c01cc9745e',NULL),
(28,'2024-05-31 23:14:22','2024-05-31 23:14:22',15,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(29,'2024-05-31 23:18:13','2024-05-31 23:18:13',16,'import_hash_v2','\"65238e6246cb715e6562b1e0039be80fdfda1e7852d0c766fe1dd305e7fa8c62\"','2f3a98cf6749c34e44fac0fbb24897afbefb7e86f4bed4cdefc1830d89a0eb7d',NULL),
(30,'2024-05-31 23:18:13','2024-05-31 23:18:13',16,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(31,'2024-05-31 23:18:55','2024-05-31 23:18:55',17,'import_hash_v2','\"aae0ba7d39205bb71d835c34b66cc690be7b9155a900d30c864beaad0b0bf647\"','6e4baaeed605d4d6904056ac9fedc27e08995a210377c5930845dcda1053aafe',NULL),
(32,'2024-05-31 23:18:55','2024-05-31 23:18:55',17,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(33,'2024-05-31 23:20:07','2024-05-31 23:20:07',18,'import_hash_v2','\"202f72130da68b989edb4178ba4deaf0830630849bbcfd140b7fc5fb68e75e9b\"','7f78da7c8195983f32deeca96ddf058c1118185ed85eaac8dc38a0520fcc4ad3',NULL),
(34,'2024-05-31 23:20:07','2024-05-31 23:20:07',18,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(35,'2024-05-31 23:22:35','2024-05-31 23:22:35',19,'import_hash_v2','\"dd45b616a0c356098cf7d208ce4ba3c76b096f0e38a5b51d53cf2de59a5122ff\"','68325f87e3867f945de650205376be67850b80d6f99103e72b8ed49819857408',NULL),
(36,'2024-05-31 23:22:35','2024-05-31 23:22:35',19,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(37,'2024-06-03 14:36:05','2024-06-03 14:36:05',20,'import_hash_v2','\"8ebebf86ffe214348a976eabbc049d6eb63667d1756eb1682c2775303f88fab7\"','bacc698ea65a6b4bc28d4246801034201d8928acbd2b6d8596c1d3a9722c8e3e',NULL),
(38,'2024-06-03 14:36:05','2024-06-03 14:36:05',20,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(39,'2024-06-03 14:37:59','2024-06-03 14:37:59',21,'import_hash_v2','\"869810bc75d64041df4892eccd8b9b45d9ba697de0d342279b45dfe76540fd6d\"','d21863633a5d43776e0cd9fd5af232fe2a0dae14ec6aabb5b2fddeaffc4e9169',NULL),
(40,'2024-06-03 14:37:59','2024-06-03 14:37:59',21,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(41,'2024-06-03 14:39:56','2024-06-03 14:39:56',22,'import_hash_v2','\"063b38d2b6ead7832e37e3a1817e856b8d5960cacc8af17c36889c631877dc6b\"','8ff530c0cd9f46b0a26ab2aac70463111f9695d19b41ae9baa4b91d63dfec619',NULL),
(42,'2024-06-03 14:39:56','2024-06-03 14:39:56',22,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(43,'2024-06-03 14:40:13','2024-06-03 14:40:13',23,'import_hash_v2','\"6e3bf748ec9a077788f8cd1e2893ecd9fdcadcaf8651a7d7223297203bdd47da\"','868a2e69f641c0f1279ca85041ebefb519a35b5c92e58fb93e0535bbbf5c3a25',NULL),
(44,'2024-06-03 14:40:13','2024-06-03 14:40:13',23,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(45,'2024-06-03 14:40:38','2024-06-03 14:40:38',24,'import_hash_v2','\"b17ebd80e4ee3d91e7ef14fdb09453be619be9573ea8097890855014e16448c5\"','76a84e14c084e13db31faf327882c1c42997a0179e3d9325fd1206a351bbc08d',NULL),
(46,'2024-06-03 14:40:38','2024-06-03 14:40:38',24,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(47,'2024-06-03 14:40:54','2024-06-03 14:40:54',25,'import_hash_v2','\"6bd8abe3b3db1d35c57eacd7eab9feb685a9d7c4d74265cf95b14365d2ae5d53\"','b234dd920775c9d0758289baefd2f1884bee5fc09f74ee4c14bb129c3f4036b7',NULL),
(48,'2024-06-03 14:40:54','2024-06-03 14:40:54',25,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(49,'2024-06-03 14:41:55','2024-06-03 14:41:55',26,'import_hash_v2','\"346c9bcacfad4723c3241695af190075d41aed04d3fdf07c8a265fc6d7b0085c\"','fda403db7f02ddf6f79c04be1934a9e1a34b1282bf49ee9832eba1436a3c313f',NULL),
(50,'2024-06-03 14:41:55','2024-06-03 14:41:55',26,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(51,'2024-06-04 22:14:57','2024-06-04 22:14:57',27,'import_hash_v2','\"eb66f90eee0ebd94d9a6723791e310ec6da8d0b6d07203982f33786dbe5188bc\"','31a4161f5a60c7410ba57fc5c3bcbc6ad50690a8185ea5f113914bea4975de54',NULL),
(52,'2024-06-04 22:14:58','2024-06-04 22:14:58',27,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(53,'2024-06-05 21:21:35','2024-06-05 21:21:35',28,'import_hash_v2','\"b7c03d63f88f27d8b4dd5c558c0386aa8772fa0629435f68f76c97a1d30f9b32\"','7fd9f55223d08f29837e8dc81bd5b4f24550c2cc068392cefdf3601ac00aed26',NULL),
(54,'2024-06-05 21:21:35','2024-06-05 21:21:35',28,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(55,'2024-06-05 21:22:54','2024-06-05 21:22:54',29,'import_hash_v2','\"bfffc2dc8d4bafd000b81d09a70d4f08ff430fb81a680873b05fb43519cab15f\"','81786357d32a8f063c4818d0436f2c9cc005a7c5b1b0af28f5f1a73e4c18c698',NULL),
(56,'2024-06-05 21:22:54','2024-06-05 21:22:54',29,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(57,'2024-06-05 21:23:12','2024-06-05 21:23:12',30,'import_hash_v2','\"7db9a6dab5daaca8c3784a8f71179748395af05df01a5f75567e6635ff3d3400\"','070cad6009caa98cc5428df187afe7dddb6d9a41c09e1e9d4547ec04ea16d5fd',NULL),
(58,'2024-06-05 21:23:12','2024-06-05 21:23:12',30,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(59,'2024-06-05 21:25:16','2024-06-05 21:25:16',31,'import_hash_v2','\"f8778faa7ee35199aa391e38c6269f1b42c1e2401994129a59eeb7f9127bcd18\"','55c708b7756b62b65c834ce5fee25791092ee7ef0a967b6766629fdc98df014b',NULL),
(60,'2024-06-05 21:25:16','2024-06-05 21:25:16',31,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(61,'2024-06-05 21:29:14','2024-06-05 21:29:14',32,'import_hash_v2','\"5cac12178a7ae87788d37cce8713030522806ffb8973f3d6e4b71a6c6bd54ba8\"','ec1b1a04325dbc0c6867f31aba03c4aa92d4dfe00e49a2c922c80a1b6482455d',NULL),
(62,'2024-06-05 21:29:14','2024-06-05 21:29:14',33,'import_hash_v2','\"b9728e61c42ba025d8b45a814c49af754b66d910a5cd4c1f2c2fcd4c2a73000d\"','b533154b46de79f4ec2598a695706df819faa599b6168bb24fab14e29e8cdaac','2024-06-05 21:29:14'),
(63,'2024-06-05 21:34:11','2024-06-05 21:34:11',34,'import_hash_v2','\"3b80ca342b4cbbe8f2932f3ca72f0ff76b8d8332f9ad536ea3cda6f0a9897ab0\"','19e95253abbde26d9043db90612fe16459d30e230c0314cb92054a1b2980d72c',NULL),
(64,'2024-06-05 21:34:11','2024-06-05 21:34:11',35,'import_hash_v2','\"2b9202c79cae50662f2f000ae8a7c00f89f8cc989e4397b51b26f65c336247c6\"','2fc0ca8a38b27b34bfb0fe38462cf42d1f2049e581c7ac7fe4026ed868a98270','2024-06-05 21:34:11'),
(65,'2024-06-05 22:58:12','2024-06-05 22:58:12',36,'import_hash_v2','\"291e2695d1bdbd5c5b793b907f5195d7c12613e7583c8c73ec91f1fad48da928\"','5a9e0596834be14716b9083058e9121da1d81551046a4fb4bbcf00b58247624d',NULL),
(66,'2024-06-05 22:58:12','2024-06-05 22:58:12',36,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(67,'2024-06-06 00:08:02','2024-06-06 00:08:02',37,'import_hash_v2','\"21a2062b2f08b05b80bc8bb27fcfe73c226f8bc72bed57ff6893bf2cba3ed080\"','aade336d88459dcb717e3c1e519c0d1b41843ad8841a24a78cd39bd860a01ac1',NULL),
(68,'2024-06-06 00:08:02','2024-06-06 00:08:02',37,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(69,'2024-06-06 23:33:48','2024-06-06 23:33:48',38,'import_hash_v2','\"ebbebdd3c732574fe9893a9af350409cbe652d928995ad96f2306829569a8518\"','a6e7d5a8fbbca26c7a00f740cf9cabaf74012cba1e440f0ff82bf5c87e36ab82',NULL),
(70,'2024-06-06 23:33:48','2024-06-06 23:33:48',38,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(71,'2024-06-06 23:35:19','2024-06-06 23:35:19',39,'import_hash_v2','\"f48ac98340daad1b67e78fcedc65bc255a3c2572f4df58ed0e4e91a136cd023b\"','01f524b4a9a2f24b71885cf316ae7ab8d04412a581c34b6523d83653e64f5b59',NULL),
(72,'2024-06-06 23:35:19','2024-06-06 23:35:19',39,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(73,'2024-06-06 23:35:59','2024-06-06 23:35:59',40,'import_hash_v2','\"30c12611bcbf889e550c8eab1c0190e0166818de56f0441cfef5320ec338596b\"','4c66daaa4cf080dd32637db291f182b28ca3db3604067d0d90fdaedd2bc02a11',NULL),
(74,'2024-06-06 23:35:59','2024-06-06 23:35:59',40,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(75,'2024-06-07 22:11:01','2024-06-07 22:11:01',41,'import_hash_v2','\"dee66b47243834133f39e18b6d450e141257958b7a6853a4c63d9c284c551af2\"','7e4615348699a11831bbd80a5ac717957330f5368d7b380804eb6e2a85219ed3',NULL),
(76,'2024-06-07 22:11:01','2024-06-07 22:11:01',41,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(77,'2024-06-07 22:13:29','2024-06-07 22:13:29',42,'import_hash_v2','\"d7303c7850ee91ef97e420a4e9a3636eccc883b40692e525824fa5c519c92aaa\"','3467433d2d3e9d68c3748bd6c2c83469976e9b9965f2844f14f196886e2c1289',NULL),
(78,'2024-06-07 22:13:29','2024-06-07 22:13:29',42,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(79,'2024-06-07 22:16:58','2024-06-07 22:16:58',43,'import_hash_v2','\"15334aa3208c61c26ee23198a291a214839a2e6f03d1e9e8f6856a71956b47e0\"','dd4463eb3b93940e4a1fb3c10f1a7b1899b279d66e1ad12a6728701844e4cab2',NULL),
(80,'2024-06-07 22:16:58','2024-06-07 22:16:58',43,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(81,'2024-06-07 22:20:59','2024-06-07 22:20:59',44,'import_hash_v2','\"cd907cdf287ff7e2dc895b4113e021bc002a11dc5d7073d9569984a81707dd53\"','23aa567ae5d0a7d9f8e73a053da1190a762db3ffb75dde7ea70390dd07fbed64',NULL),
(82,'2024-06-07 22:20:59','2024-06-07 22:20:59',44,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(83,'2024-06-07 22:23:04','2024-06-07 22:23:04',45,'import_hash_v2','\"cf38e067a5573c8ddb9e74f97299d6720dcd04e3496975720129a8895ca807f3\"','7c288d175b28975aa623c7089ba1beed60eb60567eeab0263b6eb632999a7b55',NULL),
(84,'2024-06-07 22:23:04','2024-06-07 22:23:04',45,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(85,'2024-06-07 22:24:13','2024-06-07 22:24:13',46,'import_hash_v2','\"548d5aa3da01f4a3dfab71450455ea3bd9ad4d7c57bec21e5d602b4dca9b8a71\"','ef60961793ea07cb115a01751451de78eaa4fb37c5cc363d723fb6636b8317bc',NULL),
(86,'2024-06-07 22:24:13','2024-06-07 22:24:13',46,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(87,'2024-06-07 22:28:39','2024-06-07 22:28:39',47,'import_hash_v2','\"1396e3a67b4a9b2cd49256bd098a4a88c75f3efbf9f4afe41ed5a27b0293e3ab\"','02b2da46467093d73f987952ef8f61b29a6a0097573d21d6f407037c3a42211d',NULL),
(88,'2024-06-07 22:29:35','2024-06-07 22:29:35',48,'import_hash_v2','\"211ae9138e4724911e8221c2684414db2882cf2f8aa3a322d99b9cdeeddc4ad3\"','f5891e25a15928b6bec701821958c941fd2319d1539613c3fe04357e6b57a9a2',NULL),
(89,'2024-06-07 22:29:35','2024-06-07 22:29:35',48,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(90,'2024-06-07 22:30:37','2024-06-07 22:30:37',49,'import_hash_v2','\"ff0c5cce46fabce0db4fc0b7ec4d007f1b22ab8dea99d81963835d624c448e83\"','6310b15aa7a622181e900f40f784ef47f20e35377928395d59f39efe822d16fe',NULL),
(91,'2024-06-07 22:30:37','2024-06-07 22:30:37',49,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL),
(92,'2024-06-07 22:32:42','2024-06-07 22:34:30',50,'import_hash_v2','\"010d67dc2accd83ac7c786148cbe7bd9c7ffa8c14d6744249b82f4f3c71fd796\"','82f500d7268462bc9b5a45135b184dcb993aa7e3bef95dcb2739693ca2a253a1','2024-06-07 22:34:30'),
(93,'2024-06-07 22:32:42','2024-06-07 22:34:30',50,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2','2024-06-07 22:34:30'),
(94,'2024-06-07 22:35:21','2024-06-07 22:35:21',51,'import_hash_v2','\"d74b5791c27379cb8bb068cc39d0a03f99fd4eefca94f90a2038c9fad5c11cb5\"','025be0e1269ffb83fd298de6dfaa90f57ec361ab28b80cc62c51fa39ac7dea30',NULL),
(95,'2024-06-07 22:35:21','2024-06-07 22:35:21',51,'original_source','\"ff3-v6.1.16|api-v2.1.0\"','1f52f080ddb09df75e7b78c994b90122fa4f092d4a70d531badb50a0fa1785c2',NULL);
/*!40000 ALTER TABLE `journal_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `limit_repetitions`
--

DROP TABLE IF EXISTS `limit_repetitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `limit_repetitions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `budget_limit_id` int(10) unsigned NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `amount` decimal(32,12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `limit_repetitions_budget_limit_id_foreign` (`budget_limit_id`),
  CONSTRAINT `limit_repetitions_budget_limit_id_foreign` FOREIGN KEY (`budget_limit_id`) REFERENCES `budget_limits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `limit_repetitions`
--

LOCK TABLES `limit_repetitions` WRITE;
/*!40000 ALTER TABLE `limit_repetitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `limit_repetitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link_types`
--

DROP TABLE IF EXISTS `link_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `outward` varchar(191) NOT NULL,
  `inward` varchar(191) NOT NULL,
  `editable` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `link_types_name_outward_inward_unique` (`name`,`outward`,`inward`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link_types`
--

LOCK TABLES `link_types` WRITE;
/*!40000 ALTER TABLE `link_types` DISABLE KEYS */;
INSERT INTO `link_types` VALUES
(1,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Related','relates to','relates to',0),
(2,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Refund','(partially) refunds','is (partially) refunded by',0),
(3,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Paid','(partially) pays for','is (partially) paid for by',0),
(4,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Reimbursement','(partially) reimburses','is (partially) reimbursed by',0);
/*!40000 ALTER TABLE `link_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `locatable_id` int(10) unsigned NOT NULL,
  `locatable_type` varchar(255) NOT NULL,
  `latitude` decimal(12,8) DEFAULT NULL,
  `longitude` decimal(12,8) DEFAULT NULL,
  `zoom_level` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2016_06_16_000000_create_support_tables',1),
(2,'2016_06_16_000001_create_users_table',1),
(3,'2016_06_16_000002_create_main_tables',1),
(4,'2016_08_25_091522_changes_for_3101',1),
(5,'2016_09_12_121359_fix_nullables',1),
(6,'2016_10_09_150037_expand_transactions_table',1),
(7,'2016_10_22_075804_changes_for_v410',1),
(8,'2016_11_24_210552_changes_for_v420',1),
(9,'2016_12_22_150431_changes_for_v430',1),
(10,'2016_12_28_203205_changes_for_v431',1),
(11,'2017_04_13_163623_changes_for_v440',1),
(12,'2017_06_02_105232_changes_for_v450',1),
(13,'2017_08_20_062014_changes_for_v470',1),
(14,'2017_11_04_170844_changes_for_v470a',1),
(15,'2018_01_01_000001_create_oauth_auth_codes_table',1),
(16,'2018_01_01_000002_create_oauth_access_tokens_table',1),
(17,'2018_01_01_000003_create_oauth_refresh_tokens_table',1),
(18,'2018_01_01_000004_create_oauth_clients_table',1),
(19,'2018_01_01_000005_create_oauth_personal_access_clients_table',1),
(20,'2018_03_19_141348_changes_for_v472',1),
(21,'2018_04_07_210913_changes_for_v473',1),
(22,'2018_04_29_174524_changes_for_v474',1),
(23,'2018_06_08_200526_changes_for_v475',1),
(24,'2018_09_05_195147_changes_for_v477',1),
(25,'2018_11_06_172532_changes_for_v479',1),
(26,'2019_01_28_193833_changes_for_v4710',1),
(27,'2019_02_05_055516_changes_for_v4711',1),
(28,'2019_02_11_170529_changes_for_v4712',1),
(29,'2019_03_11_223700_fix_ldap_configuration',1),
(30,'2019_03_22_183214_changes_for_v480',1),
(31,'2019_11_30_000000_create_2fa_token_table',1),
(32,'2019_12_28_191351_make_locations_table',1),
(33,'2020_03_13_201950_changes_for_v520',1),
(34,'2020_06_07_063612_changes_for_v530',1),
(35,'2020_06_30_202620_changes_for_v530a',1),
(36,'2020_07_24_162820_changes_for_v540',1),
(37,'2020_11_12_070604_changes_for_v550',1),
(38,'2021_03_12_061213_changes_for_v550b2',1),
(39,'2021_05_09_064644_add_ldap_columns_to_users_table',1),
(40,'2021_05_13_053836_extend_currency_info',1),
(41,'2021_07_05_193044_drop_tele_table',1),
(42,'2021_08_28_073733_user_groups',1),
(43,'2021_12_27_000001_create_local_personal_access_tokens_table',1),
(44,'2022_08_21_104626_add_user_groups',1),
(45,'2022_09_18_123911_create_notifications_table',1),
(46,'2022_10_01_074908_invited_users',1),
(47,'2022_10_01_210238_audit_log_entries',1),
(48,'2023_08_11_192521_upgrade_og_table',1),
(49,'2023_10_21_113213_add_currency_pivot_tables',1),
(50,'2024_03_03_174645_add_indices',1),
(51,'2024_04_01_174351_expand_preferences_table',1),
(52,'2024_05_12_060551_create_account_balance_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `noteable_id` int(10) unsigned NOT NULL,
  `noteable_type` varchar(191) NOT NULL,
  `title` varchar(191) DEFAULT NULL,
  `text` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES
(1,'2024-05-25 14:59:10','2024-05-25 15:20:18','2024-05-25 15:20:18',1,'FireflyIII\\Models\\PiggyBank',NULL,'1tb ssd storage upgrade for my laptop'),
(2,'2024-05-25 15:04:15','2024-05-25 15:04:15',NULL,9,'FireflyIII\\Models\\Account',NULL,'Anything I buy for myself'),
(3,'2024-05-25 15:21:01','2024-05-25 15:21:01',NULL,2,'FireflyIII\\Models\\PiggyBank',NULL,'1tb ssd storage upgrade for my laptop'),
(4,'2024-06-03 14:36:05','2024-06-03 14:36:05',NULL,20,'FireflyIII\\Models\\TransactionJournal',NULL,'Infinitiee Shirt Ivory White XL'),
(5,'2024-06-03 14:41:55','2024-06-03 14:41:55',NULL,26,'FireflyIII\\Models\\TransactionJournal',NULL,'Mommy snacks'),
(6,'2024-06-05 21:25:16','2024-06-05 21:25:16',NULL,31,'FireflyIII\\Models\\TransactionJournal',NULL,'Infinitee shrts\nx1 Navy Blue - 125\nx1 Black - 126\nx1 Jungle - 126'),
(7,'2024-06-05 21:34:11','2024-06-05 21:34:11',NULL,15,'FireflyIII\\Models\\Account',NULL,'Loan for1 laptop storage upgrade, Lexar NM710 1TB'),
(8,'2024-06-06 00:08:02','2024-06-06 00:08:02',NULL,37,'FireflyIII\\Models\\TransactionJournal',NULL,'For pocholo\'s completion fees'),
(9,'2024-06-06 23:33:48','2024-06-07 22:14:42',NULL,38,'FireflyIII\\Models\\TransactionJournal',NULL,'Borrowed money, 530\n500 = actual amount\n15 = instapay fee\n15 = cash out fee\n\nReason: For food purchase at tiangge'),
(10,'2024-06-07 22:11:01','2024-06-07 22:11:01',NULL,41,'FireflyIII\\Models\\TransactionJournal',NULL,'cholo completion fee return'),
(11,'2024-06-07 22:13:29','2024-06-07 22:13:29',NULL,42,'FireflyIII\\Models\\TransactionJournal',NULL,'Ate Pat returned money from yesterday\'s financial help'),
(12,'2024-06-07 22:16:58','2024-06-07 22:16:58',NULL,43,'FireflyIII\\Models\\TransactionJournal',NULL,'Jeep Fare  = 104\nCarousel Bus Fare = 68'),
(13,'2024-06-07 22:20:59','2024-06-07 22:20:59',NULL,44,'FireflyIII\\Models\\TransactionJournal',NULL,'settlement for two co-workers for their drinks\n\nmine = 200\ntheirs = 197.5 x 2\ntotal = 595\n\nsettled amount = 500\ntheir additionals = 100\ntotal = 600\n\nchange = 5'),
(14,'2024-06-07 22:28:39','2024-06-07 22:28:39',NULL,47,'FireflyIII\\Models\\TransactionJournal',NULL,'settlement for two co-workers for their drinks\n\nmine = 200\ntheirs = 197.5 x 2\ntotal = 595\n\nsettled amount = 500\ntheir additionals = 100\ntotal = 600\n\nchange = 5');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(191) NOT NULL,
  `notifiable_type` varchar(191) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `provider` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_personal_access_clients`
--

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_groupables`
--

DROP TABLE IF EXISTS `object_groupables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_groupables` (
  `object_group_id` int(11) NOT NULL,
  `object_groupable_id` int(10) unsigned NOT NULL,
  `object_groupable_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_groupables`
--

LOCK TABLES `object_groupables` WRITE;
/*!40000 ALTER TABLE `object_groupables` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_groupables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_groups`
--

DROP TABLE IF EXISTS `object_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `order` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `object_groups_user_id_foreign` (`user_id`),
  KEY `object_groups_to_ugi` (`user_group_id`),
  CONSTRAINT `object_groups_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `object_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_groups`
--

LOCK TABLES `object_groups` WRITE;
/*!40000 ALTER TABLE `object_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_role` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `display_name` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piggy_bank_events`
--

DROP TABLE IF EXISTS `piggy_bank_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `piggy_bank_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `piggy_bank_id` int(10) unsigned NOT NULL,
  `transaction_journal_id` int(10) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `amount` decimal(32,12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `piggy_bank_events_piggy_bank_id_foreign` (`piggy_bank_id`),
  KEY `piggy_bank_events_transaction_journal_id_foreign` (`transaction_journal_id`),
  CONSTRAINT `piggy_bank_events_piggy_bank_id_foreign` FOREIGN KEY (`piggy_bank_id`) REFERENCES `piggy_banks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `piggy_bank_events_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piggy_bank_events`
--

LOCK TABLES `piggy_bank_events` WRITE;
/*!40000 ALTER TABLE `piggy_bank_events` DISABLE KEYS */;
INSERT INTO `piggy_bank_events` VALUES
(1,'2024-05-25 15:21:10','2024-05-25 15:21:10',2,NULL,'2024-05-25',500.000000000000),
(2,'2024-05-31 14:12:21','2024-05-31 14:12:21',2,NULL,'2024-05-31',3500.000000000000);
/*!40000 ALTER TABLE `piggy_bank_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piggy_bank_repetitions`
--

DROP TABLE IF EXISTS `piggy_bank_repetitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `piggy_bank_repetitions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `piggy_bank_id` int(10) unsigned NOT NULL,
  `startdate` date DEFAULT NULL,
  `targetdate` date DEFAULT NULL,
  `currentamount` decimal(32,12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `piggy_bank_repetitions_piggy_bank_id_foreign` (`piggy_bank_id`),
  CONSTRAINT `piggy_bank_repetitions_piggy_bank_id_foreign` FOREIGN KEY (`piggy_bank_id`) REFERENCES `piggy_banks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piggy_bank_repetitions`
--

LOCK TABLES `piggy_bank_repetitions` WRITE;
/*!40000 ALTER TABLE `piggy_bank_repetitions` DISABLE KEYS */;
INSERT INTO `piggy_bank_repetitions` VALUES
(2,'2024-05-25 15:21:01','2024-05-31 14:12:21',2,'2024-05-25','2024-09-30',4000.000000000000);
/*!40000 ALTER TABLE `piggy_bank_repetitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piggy_banks`
--

DROP TABLE IF EXISTS `piggy_banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `piggy_banks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `name` varchar(1024) NOT NULL,
  `targetamount` decimal(32,12) NOT NULL,
  `startdate` date DEFAULT NULL,
  `targetdate` date DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `encrypted` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `piggy_banks_account_id_foreign` (`account_id`),
  CONSTRAINT `piggy_banks_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piggy_banks`
--

LOCK TABLES `piggy_banks` WRITE;
/*!40000 ALTER TABLE `piggy_banks` DISABLE KEYS */;
INSERT INTO `piggy_banks` VALUES
(1,'2024-05-25 14:59:10','2024-05-25 15:20:18','2024-05-25 15:20:18',1,'Laptop Storage Upgrade Plan',4000.000000000000,'2024-05-25','2024-09-30',1,0,1),
(2,'2024-05-25 15:21:01','2024-05-25 15:21:01',NULL,3,'Laptop Storage Upgrade',4000.000000000000,'2024-05-25','2024-09-30',1,0,1);
/*!40000 ALTER TABLE `piggy_banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(1024) NOT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `preferences_user_id_foreign` (`user_id`),
  KEY `preferences_to_ugi` (`user_group_id`),
  CONSTRAINT `preferences_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `preferences_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferences`
--

LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;
INSERT INTO `preferences` VALUES
(1,'2024-05-25 14:51:59','2024-05-25 14:51:59',1,NULL,'viewRange','\"1M\"'),
(2,'2024-05-25 14:51:59','2024-05-25 14:51:59',1,NULL,'language','\"en_US\"'),
(3,'2024-05-25 14:51:59','2024-05-25 14:51:59',1,NULL,'locale','\"equal\"'),
(4,'2024-05-25 14:51:59','2024-06-07 22:37:21',1,1,'lastActivity','\"0.27731400 1717771041\"'),
(5,'2024-05-25 14:51:59','2024-05-25 14:51:59',1,NULL,'list-length','10'),
(6,'2024-05-25 14:51:59','2024-05-25 14:51:59',1,NULL,'darkMode','\"browser\"'),
(7,'2024-05-25 14:52:04','2024-05-25 14:54:17',1,NULL,'shown_demo_index','true'),
(8,'2024-05-25 14:52:19','2024-06-07 22:09:38',1,NULL,'login_ip_history','[{\"ip\":\"172.23.0.1\",\"time\":\"2024-05-25 15:21:19\",\"notified\":true},{\"ip\":\"172.24.0.1\",\"time\":\"2024-06-06 23:32:04\",\"notified\":true},{\"ip\":\"172.19.0.1\",\"time\":\"2024-05-31 14:05:23\",\"notified\":true},{\"ip\":\"172.20.0.1\",\"time\":\"2024-05-31 23:12:41\",\"notified\":true},{\"ip\":\"192.168.80.1\",\"time\":\"2024-06-07 22:09:38\",\"notified\":true}]'),
(9,'2024-05-25 14:52:19','2024-05-25 14:52:19',1,NULL,'notification_user_login','true'),
(10,'2024-05-25 14:52:19','2024-05-25 14:52:19',1,NULL,'slack_webhook_url','\"\"'),
(11,'2024-05-25 14:52:31','2024-05-25 14:52:34',1,NULL,'shown_demo_currencies_index','true'),
(12,'2024-05-25 14:52:31','2024-05-25 14:52:31',1,NULL,'listPageSize','50'),
(13,'2024-05-25 14:52:34','2024-05-25 14:52:36',1,NULL,'shown_demo_currencies_create','true'),
(14,'2024-05-25 14:54:13','2024-05-25 14:54:13',1,1,'frontpageAccounts','[1,3,5]'),
(15,'2024-05-25 14:54:13','2024-05-25 14:54:13',1,NULL,'transaction_journal_optional_fields','{\"interest_date\":true,\"book_date\":false,\"process_date\":false,\"due_date\":false,\"payment_date\":false,\"invoice_date\":false,\"internal_reference\":false,\"notes\":true,\"attachments\":true}'),
(16,'2024-05-25 14:54:21','2024-05-25 14:54:25',1,NULL,'shown_demo_transactions_create_transfer','true'),
(17,'2024-05-25 14:55:15','2024-05-25 14:55:17',1,NULL,'shown_demo_accounts_create_expense','true'),
(18,'2024-05-25 14:55:41','2024-05-25 14:55:41',1,NULL,'customFiscalYear','false'),
(19,'2024-05-25 14:55:55','2024-05-25 14:55:57',1,NULL,'shown_demo_accounts_create_liabilities','true'),
(20,'2024-05-25 14:56:18','2024-05-25 14:56:19',1,NULL,'shown_demo_accounts_create_revenue','true'),
(21,'2024-05-25 14:57:29','2024-05-25 14:57:29',1,NULL,'shown_demo_budgets_index','false'),
(22,'2024-05-25 14:57:45','2024-05-25 14:57:53',1,NULL,'shown_demo_transactions_create_deposit','true'),
(23,'2024-05-25 14:58:12','2024-05-25 14:58:29',1,NULL,'shown_demo_piggy-banks_create','true'),
(24,'2024-05-25 15:19:37','2024-05-25 15:19:39',1,NULL,'shown_demo_piggy-banks_index','true'),
(25,'2024-05-25 15:20:05','2024-05-25 15:20:07',1,NULL,'shown_demo_piggy-banks_show','true'),
(26,'2024-05-26 13:04:53','2024-05-26 13:04:53',1,NULL,'access_token','\"9a4cc3966df09128aa3bc87f900e91e3\"'),
(27,'2024-05-26 14:20:14','2024-05-26 14:20:16',1,NULL,'shown_demo_reports_index','true'),
(28,'2024-05-31 14:08:57','2024-05-31 14:09:05',1,NULL,'shown_demo_accounts_create_asset','true'),
(29,'2024-05-31 23:14:33','2024-05-31 23:14:41',1,NULL,'shown_demo_transactions_create_withdrawal','true'),
(30,'2024-05-31 23:20:21','2024-05-31 23:20:23',1,NULL,'shown_demo_reports_report_default','true'),
(31,'2024-06-05 21:27:01','2024-06-05 21:27:01',1,NULL,'shown_demo_bills_index','false'),
(32,'2024-06-05 21:27:02','2024-06-05 21:27:05',1,NULL,'shown_demo_bills_create','true'),
(33,'2024-06-07 22:30:43','2024-06-07 22:30:44',1,NULL,'shown_demo_preferences_index','true'),
(34,'2024-06-07 22:30:43','2024-06-07 22:30:43',1,NULL,'fiscalYearStart','\"01-01\"'),
(35,'2024-06-07 22:30:43','2024-06-07 22:30:43',1,NULL,'notification_bill_reminder','true'),
(36,'2024-06-07 22:30:43','2024-06-07 22:30:43',1,NULL,'notification_new_access_token','true'),
(37,'2024-06-07 22:30:43','2024-06-07 22:30:43',1,NULL,'notification_transaction_creation','true'),
(38,'2024-06-07 22:30:43','2024-06-07 22:30:43',1,NULL,'notification_rule_action_failures','true');
/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences`
--

DROP TABLE IF EXISTS `recurrences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurrences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `transaction_type_id` int(10) unsigned NOT NULL,
  `title` varchar(1024) NOT NULL,
  `description` text NOT NULL,
  `first_date` date NOT NULL,
  `repeat_until` date DEFAULT NULL,
  `latest_date` date DEFAULT NULL,
  `repetitions` smallint(5) unsigned NOT NULL,
  `apply_rules` tinyint(1) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `recurrences_user_id_foreign` (`user_id`),
  KEY `recurrences_transaction_type_id_foreign` (`transaction_type_id`),
  KEY `recurrences_to_ugi` (`user_group_id`),
  CONSTRAINT `recurrences_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recurrences_transaction_type_id_foreign` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurrences_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences`
--

LOCK TABLES `recurrences` WRITE;
/*!40000 ALTER TABLE `recurrences` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences_meta`
--

DROP TABLE IF EXISTS `recurrences_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurrences_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `recurrence_id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recurrences_meta_recurrence_id_foreign` (`recurrence_id`),
  CONSTRAINT `recurrences_meta_recurrence_id_foreign` FOREIGN KEY (`recurrence_id`) REFERENCES `recurrences` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences_meta`
--

LOCK TABLES `recurrences_meta` WRITE;
/*!40000 ALTER TABLE `recurrences_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences_repetitions`
--

DROP TABLE IF EXISTS `recurrences_repetitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurrences_repetitions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `recurrence_id` int(10) unsigned NOT NULL,
  `repetition_type` varchar(50) NOT NULL,
  `repetition_moment` varchar(50) NOT NULL,
  `repetition_skip` smallint(5) unsigned NOT NULL,
  `weekend` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recurrences_repetitions_recurrence_id_foreign` (`recurrence_id`),
  CONSTRAINT `recurrences_repetitions_recurrence_id_foreign` FOREIGN KEY (`recurrence_id`) REFERENCES `recurrences` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences_repetitions`
--

LOCK TABLES `recurrences_repetitions` WRITE;
/*!40000 ALTER TABLE `recurrences_repetitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences_repetitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurrences_transactions`
--

DROP TABLE IF EXISTS `recurrences_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurrences_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `recurrence_id` int(10) unsigned NOT NULL,
  `transaction_currency_id` int(10) unsigned NOT NULL,
  `transaction_type_id` int(10) unsigned DEFAULT NULL,
  `foreign_currency_id` int(10) unsigned DEFAULT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `destination_id` int(10) unsigned NOT NULL,
  `amount` decimal(32,12) NOT NULL,
  `foreign_amount` decimal(32,12) DEFAULT NULL,
  `description` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recurrences_transactions_recurrence_id_foreign` (`recurrence_id`),
  KEY `recurrences_transactions_transaction_currency_id_foreign` (`transaction_currency_id`),
  KEY `recurrences_transactions_foreign_currency_id_foreign` (`foreign_currency_id`),
  KEY `recurrences_transactions_source_id_foreign` (`source_id`),
  KEY `recurrences_transactions_destination_id_foreign` (`destination_id`),
  KEY `type_foreign` (`transaction_type_id`),
  CONSTRAINT `recurrences_transactions_destination_id_foreign` FOREIGN KEY (`destination_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurrences_transactions_foreign_currency_id_foreign` FOREIGN KEY (`foreign_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recurrences_transactions_recurrence_id_foreign` FOREIGN KEY (`recurrence_id`) REFERENCES `recurrences` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurrences_transactions_source_id_foreign` FOREIGN KEY (`source_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurrences_transactions_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `type_foreign` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurrences_transactions`
--

LOCK TABLES `recurrences_transactions` WRITE;
/*!40000 ALTER TABLE `recurrences_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurrences_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES
(1,1);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `display_name` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'2024-05-25 14:51:01','2024-05-25 14:51:01','owner','Site Owner','User runs this instance of FF3'),
(2,'2024-05-25 14:51:01','2024-05-25 14:51:01','demo','Demo User','User is a demo user');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rt_meta`
--

DROP TABLE IF EXISTS `rt_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rt_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `rt_id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rt_meta_rt_id_foreign` (`rt_id`),
  CONSTRAINT `rt_meta_rt_id_foreign` FOREIGN KEY (`rt_id`) REFERENCES `recurrences_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rt_meta`
--

LOCK TABLES `rt_meta` WRITE;
/*!40000 ALTER TABLE `rt_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `rt_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_actions`
--

DROP TABLE IF EXISTS `rule_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rule_id` int(10) unsigned NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `action_value` varchar(255) NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `stop_processing` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rule_actions_rule_id_foreign` (`rule_id`),
  CONSTRAINT `rule_actions_rule_id_foreign` FOREIGN KEY (`rule_id`) REFERENCES `rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_actions`
--

LOCK TABLES `rule_actions` WRITE;
/*!40000 ALTER TABLE `rule_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_groups`
--

DROP TABLE IF EXISTS `rule_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `stop_processing` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rule_groups_user_id_foreign` (`user_id`),
  KEY `rule_groups_to_ugi` (`user_group_id`),
  CONSTRAINT `rule_groups_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `rule_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_groups`
--

LOCK TABLES `rule_groups` WRITE;
/*!40000 ALTER TABLE `rule_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_triggers`
--

DROP TABLE IF EXISTS `rule_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_triggers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rule_id` int(10) unsigned NOT NULL,
  `trigger_type` varchar(50) NOT NULL,
  `trigger_value` varchar(255) NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `stop_processing` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rule_triggers_rule_id_foreign` (`rule_id`),
  CONSTRAINT `rule_triggers_rule_id_foreign` FOREIGN KEY (`rule_id`) REFERENCES `rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_triggers`
--

LOCK TABLES `rule_triggers` WRITE;
/*!40000 ALTER TABLE `rule_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rules`
--

DROP TABLE IF EXISTS `rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `rule_group_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `stop_processing` tinyint(1) NOT NULL DEFAULT 0,
  `strict` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `rules_user_id_foreign` (`user_id`),
  KEY `rules_rule_group_id_foreign` (`rule_group_id`),
  KEY `rules_to_ugi` (`user_group_id`),
  CONSTRAINT `rules_rule_group_id_foreign` FOREIGN KEY (`rule_group_id`) REFERENCES `rule_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rules_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `rules_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rules`
--

LOCK TABLES `rules` WRITE;
/*!40000 ALTER TABLE `rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_transaction_journal`
--

DROP TABLE IF EXISTS `tag_transaction_journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag_transaction_journal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag_id` int(10) unsigned NOT NULL,
  `transaction_journal_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_transaction_journal_tag_id_transaction_journal_id_unique` (`tag_id`,`transaction_journal_id`),
  KEY `tag_transaction_journal_transaction_journal_id_foreign` (`transaction_journal_id`),
  CONSTRAINT `tag_transaction_journal_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tag_transaction_journal_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_transaction_journal`
--

LOCK TABLES `tag_transaction_journal` WRITE;
/*!40000 ALTER TABLE `tag_transaction_journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_transaction_journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `tag` varchar(1024) NOT NULL,
  `tagMode` varchar(1024) NOT NULL,
  `date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `latitude` decimal(12,8) DEFAULT NULL,
  `longitude` decimal(12,8) DEFAULT NULL,
  `zoomLevel` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tags_user_id_foreign` (`user_id`),
  KEY `tags_to_ugi` (`user_group_id`),
  CONSTRAINT `tags_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tags_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_currencies`
--

DROP TABLE IF EXISTS `transaction_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `code` varchar(51) NOT NULL,
  `name` varchar(255) NOT NULL,
  `symbol` varchar(51) NOT NULL,
  `decimal_places` smallint(5) unsigned NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_currencies_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=458 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_currencies`
--

LOCK TABLES `transaction_currencies` WRITE;
/*!40000 ALTER TABLE `transaction_currencies` DISABLE KEYS */;
INSERT INTO `transaction_currencies` VALUES
(1,'2024-05-25 14:51:01','2024-05-25 14:53:04',NULL,0,'EUR','Euro','€',2),
(2,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'HUF','Hungarian forint','Ft',2),
(3,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'GBP','British Pound','£',2),
(4,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'UAH','Ukrainian hryvnia','₴',2),
(5,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'PLN','Polish złoty','zł',2),
(6,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'TRY','Turkish lira','₺',2),
(7,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'DKK','Dansk krone','kr.',2),
(8,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'USD','US Dollar','$',2),
(9,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'BRL','Brazilian real','R$',2),
(10,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'CAD','Canadian dollar','C$',2),
(11,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'MXN','Mexican peso','MX$',2),
(12,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'IDR','Indonesian rupiah','Rp',2),
(13,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'AUD','Australian dollar','A$',2),
(14,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'NZD','New Zealand dollar','NZ$',2),
(15,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'EGP','Egyptian pound','E£',2),
(16,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'MAD','Moroccan dirham','DH',2),
(17,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'ZAR','South African rand','R',2),
(18,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'JPY','Japanese yen','¥',0),
(19,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'CNY','Chinese yuan','¥',2),
(20,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'RUB','Russian ruble','₽',2),
(21,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'INR','Indian rupee','₹',2),
(22,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'ILS','Israeli new shekel','₪',2),
(23,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'CHF','Swiss franc','CHF',2),
(24,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,0,'HRK','Croatian kuna','kn',2),
(25,'2024-05-25 14:53:00','2024-05-25 14:54:13',NULL,1,'PHP','Philippine Peso','₱',2);
/*!40000 ALTER TABLE `transaction_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_currency_user`
--

DROP TABLE IF EXISTS `transaction_currency_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_currency_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `transaction_currency_id` int(10) unsigned NOT NULL,
  `user_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_combo` (`user_id`,`transaction_currency_id`),
  KEY `transaction_currency_user_transaction_currency_id_foreign` (`transaction_currency_id`),
  CONSTRAINT `transaction_currency_user_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_currency_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_currency_user`
--

LOCK TABLES `transaction_currency_user` WRITE;
/*!40000 ALTER TABLE `transaction_currency_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_currency_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_currency_user_group`
--

DROP TABLE IF EXISTS `transaction_currency_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_currency_user_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_group_id` bigint(20) unsigned NOT NULL,
  `transaction_currency_id` int(10) unsigned NOT NULL,
  `group_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_combo_ug` (`user_group_id`,`transaction_currency_id`),
  KEY `transaction_currency_user_group_transaction_currency_id_foreign` (`transaction_currency_id`),
  CONSTRAINT `transaction_currency_user_group_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_currency_user_group_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_currency_user_group`
--

LOCK TABLES `transaction_currency_user_group` WRITE;
/*!40000 ALTER TABLE `transaction_currency_user_group` DISABLE KEYS */;
INSERT INTO `transaction_currency_user_group` VALUES
(5,'2024-05-25 14:54:13','2024-05-25 14:54:13',1,25,1);
/*!40000 ALTER TABLE `transaction_currency_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_groups`
--

DROP TABLE IF EXISTS `transaction_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_groups_user_id_index` (`user_id`),
  KEY `transaction_groups_user_group_id_index` (`user_group_id`),
  CONSTRAINT `transaction_groups_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `transaction_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_groups`
--

LOCK TABLES `transaction_groups` WRITE;
/*!40000 ALTER TABLE `transaction_groups` DISABLE KEYS */;
INSERT INTO `transaction_groups` VALUES
(1,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,1,1,NULL),
(2,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,1,1,NULL),
(3,'2024-05-25 14:54:54','2024-05-25 14:54:54',NULL,1,1,NULL),
(4,'2024-05-25 15:05:50','2024-05-25 15:14:19',NULL,1,1,'Facial Care Refill'),
(5,'2024-05-25 15:08:21','2024-05-25 15:15:18',NULL,1,1,NULL),
(6,'2024-05-25 15:09:17','2024-05-25 15:17:20',NULL,1,1,NULL),
(7,'2024-05-25 15:09:41','2024-05-25 15:16:13',NULL,1,1,NULL),
(8,'2024-05-25 15:11:08','2024-05-25 15:11:08',NULL,1,1,NULL),
(9,'2024-05-25 15:12:18','2024-05-25 15:12:18',NULL,1,1,NULL),
(10,'2024-05-25 15:13:21','2024-05-25 15:13:21',NULL,1,1,NULL),
(11,'2024-05-31 14:06:48','2024-05-31 14:06:48',NULL,1,1,NULL),
(12,'2024-05-31 14:09:59','2024-05-31 14:10:13',NULL,1,1,NULL),
(13,'2024-05-31 14:11:29','2024-05-31 14:11:29',NULL,1,1,NULL),
(14,'2024-05-31 23:14:22','2024-05-31 23:14:22',NULL,1,1,NULL),
(15,'2024-05-31 23:18:13','2024-05-31 23:18:13',NULL,1,1,NULL),
(16,'2024-05-31 23:18:55','2024-05-31 23:18:55',NULL,1,1,NULL),
(17,'2024-05-31 23:20:07','2024-05-31 23:20:07',NULL,1,1,NULL),
(18,'2024-05-31 23:22:35','2024-05-31 23:22:35',NULL,1,1,NULL),
(19,'2024-06-03 14:36:05','2024-06-03 14:36:05',NULL,1,1,NULL),
(20,'2024-06-03 14:37:59','2024-06-03 14:39:03',NULL,1,1,NULL),
(21,'2024-06-03 14:39:56','2024-06-03 14:41:05',NULL,1,1,NULL),
(22,'2024-06-03 14:40:14','2024-06-03 14:41:21',NULL,1,1,NULL),
(23,'2024-06-03 14:40:39','2024-06-03 14:40:39',NULL,1,1,NULL),
(24,'2024-06-03 14:40:54','2024-06-03 14:40:54',NULL,1,1,NULL),
(25,'2024-06-03 14:41:55','2024-06-03 14:41:55',NULL,1,1,NULL),
(26,'2024-06-04 22:14:58','2024-06-04 22:14:58',NULL,1,1,NULL),
(27,'2024-06-05 21:21:35','2024-06-05 21:21:35',NULL,1,1,NULL),
(28,'2024-06-05 21:22:54','2024-06-05 21:22:54',NULL,1,1,NULL),
(29,'2024-06-05 21:23:12','2024-06-05 21:23:12',NULL,1,1,NULL),
(30,'2024-06-05 21:25:16','2024-06-05 21:25:58',NULL,1,1,NULL),
(31,'2024-06-05 21:29:14','2024-06-05 21:29:14',NULL,1,1,NULL),
(32,'2024-06-05 21:29:14','2024-06-05 21:29:14','2024-06-05 21:29:14',1,1,NULL),
(33,'2024-06-05 21:34:11','2024-06-05 21:34:11',NULL,1,1,NULL),
(34,'2024-06-05 21:34:11','2024-06-05 21:34:11','2024-06-05 21:34:11',1,1,NULL),
(35,'2024-06-05 22:58:12','2024-06-05 22:58:12',NULL,1,1,NULL),
(36,'2024-06-06 00:08:02','2024-06-06 00:08:38',NULL,1,1,NULL),
(37,'2024-06-06 23:33:48','2024-06-07 22:14:42',NULL,1,1,NULL),
(38,'2024-06-06 23:35:19','2024-06-06 23:35:19',NULL,1,1,NULL),
(39,'2024-06-06 23:35:59','2024-06-06 23:37:24',NULL,1,1,NULL),
(40,'2024-06-07 22:11:01','2024-06-07 22:11:01',NULL,1,1,NULL),
(41,'2024-06-07 22:13:29','2024-06-07 22:37:21',NULL,1,1,NULL),
(42,'2024-06-07 22:16:58','2024-06-07 22:16:58',NULL,1,1,NULL),
(43,'2024-06-07 22:20:59','2024-06-07 22:28:39',NULL,1,1,'Starbucks'),
(44,'2024-06-07 22:23:04','2024-06-07 22:23:04',NULL,1,1,NULL),
(45,'2024-06-07 22:24:13','2024-06-07 22:36:03',NULL,1,1,NULL),
(46,'2024-06-07 22:29:35','2024-06-07 22:36:28',NULL,1,1,NULL),
(47,'2024-06-07 22:30:37','2024-06-07 22:35:45',NULL,1,1,NULL),
(48,'2024-06-07 22:32:42','2024-06-07 22:34:30','2024-06-07 22:34:30',1,1,NULL),
(49,'2024-06-07 22:35:21','2024-06-07 22:35:21',NULL,1,1,NULL);
/*!40000 ALTER TABLE `transaction_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_journals`
--

DROP TABLE IF EXISTS `transaction_journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_journals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `transaction_type_id` int(10) unsigned NOT NULL,
  `transaction_group_id` int(10) unsigned DEFAULT NULL,
  `bill_id` int(10) unsigned DEFAULT NULL,
  `transaction_currency_id` int(10) unsigned DEFAULT NULL,
  `description` varchar(1024) NOT NULL,
  `date` datetime NOT NULL,
  `interest_date` date DEFAULT NULL,
  `book_date` date DEFAULT NULL,
  `process_date` date DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `tag_count` int(10) unsigned NOT NULL,
  `encrypted` tinyint(1) NOT NULL DEFAULT 1,
  `completed` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `transaction_journals_user_id_index` (`user_id`),
  KEY `transaction_journals_user_group_id_index` (`user_group_id`),
  KEY `transaction_journals_date_index` (`date`),
  KEY `transaction_journals_transaction_group_id_index` (`transaction_group_id`),
  KEY `transaction_journals_transaction_type_id_index` (`transaction_type_id`),
  KEY `transaction_journals_transaction_currency_id_index` (`transaction_currency_id`),
  KEY `transaction_journals_bill_id_index` (`bill_id`),
  CONSTRAINT `transaction_journals_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transaction_journals_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `transaction_journals_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_journals_transaction_group_id_foreign` FOREIGN KEY (`transaction_group_id`) REFERENCES `transaction_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_journals_transaction_type_id_foreign` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_journals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_journals`
--

LOCK TABLES `transaction_journals` WRITE;
/*!40000 ALTER TABLE `transaction_journals` DISABLE KEYS */;
INSERT INTO `transaction_journals` VALUES
(1,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,1,1,4,1,NULL,25,'Initial balance for \"Maya\"','2024-05-25 14:54:13',NULL,NULL,NULL,0,0,1,1),
(2,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,1,1,4,2,NULL,25,'Initial balance for \"Maya savings account\"','2024-05-25 14:54:13',NULL,NULL,NULL,0,0,1,1),
(3,'2024-05-25 14:54:54','2024-05-25 14:54:54',NULL,1,1,3,3,NULL,25,'Emergency Fund','2024-05-25 14:54:00',NULL,NULL,NULL,0,0,1,1),
(4,'2024-05-25 15:05:50','2024-05-25 15:14:19',NULL,1,1,1,4,NULL,25,'Cetaphil Foaming Cleanser','2024-05-15 15:20:00',NULL,NULL,NULL,0,0,1,1),
(5,'2024-05-25 15:05:50','2024-05-25 15:14:19',NULL,1,1,1,4,NULL,25,'Celeteque Moisturizer','2024-05-15 15:20:00',NULL,NULL,NULL,0,0,1,1),
(6,'2024-05-25 15:08:21','2024-05-25 15:15:18',NULL,1,1,1,5,NULL,25,'Bibi Transfer','2024-05-17 22:22:00',NULL,NULL,NULL,0,0,1,1),
(7,'2024-05-25 15:09:17','2024-05-25 15:17:20',NULL,1,1,1,6,NULL,25,'Laptop Bag','2024-05-16 18:08:00',NULL,NULL,NULL,0,0,1,1),
(8,'2024-05-25 15:09:41','2024-05-25 15:16:13',NULL,1,1,1,7,NULL,25,'Financial Help','2024-05-16 18:08:00',NULL,NULL,NULL,0,0,1,1),
(9,'2024-05-25 15:11:08','2024-05-25 15:11:08',NULL,1,1,1,8,NULL,25,'Mcdo Dinner','2024-05-20 20:26:00',NULL,NULL,NULL,0,0,1,1),
(10,'2024-05-25 15:12:18','2024-05-25 15:12:18',NULL,1,1,1,9,NULL,25,'Smart Load','2024-05-24 16:45:00',NULL,NULL,NULL,0,0,1,1),
(11,'2024-05-25 15:13:21','2024-05-25 15:13:21',NULL,1,1,1,10,NULL,25,'Cooking Gas','2024-05-25 13:58:00',NULL,NULL,NULL,0,0,1,1),
(12,'2024-05-31 14:06:48','2024-05-31 14:06:48',NULL,1,1,1,11,NULL,25,'Workout Gloves','2024-05-31 14:05:00',NULL,NULL,NULL,0,0,1,1),
(13,'2024-05-31 14:09:59','2024-05-31 14:09:59',NULL,1,1,2,12,NULL,25,'Internship Pay','2024-05-31 12:48:00',NULL,NULL,NULL,0,0,1,1),
(14,'2024-05-31 14:11:28','2024-05-31 14:11:29',NULL,1,1,3,13,NULL,25,'Emergency Fund','2024-05-31 14:01:00',NULL,NULL,NULL,0,0,1,1),
(15,'2024-05-31 23:14:22','2024-05-31 23:14:22',NULL,1,1,1,14,NULL,25,'Bibi','2024-05-31 23:14:00',NULL,NULL,NULL,0,0,1,1),
(16,'2024-05-31 23:18:13','2024-05-31 23:18:13',NULL,1,1,1,15,NULL,25,'Financial Help','2024-05-31 18:50:00',NULL,NULL,NULL,0,0,1,1),
(17,'2024-05-31 23:18:55','2024-05-31 23:18:55',NULL,1,1,3,16,NULL,25,'Cash Withdrawal','2024-05-31 18:50:00',NULL,NULL,NULL,0,0,1,1),
(18,'2024-05-31 23:20:07','2024-05-31 23:20:07',NULL,1,1,1,17,NULL,25,'Pizza Treat','2024-05-31 18:22:00',NULL,NULL,NULL,0,0,1,1),
(19,'2024-05-31 23:22:35','2024-05-31 23:22:35',NULL,1,1,2,18,NULL,25,'Balance Adjustment','2024-05-31 23:21:00',NULL,NULL,NULL,0,0,1,1),
(20,'2024-06-03 14:36:04','2024-06-03 14:36:05',NULL,1,1,1,19,NULL,25,'Clothing','2024-06-03 14:34:00',NULL,NULL,NULL,0,0,1,1),
(21,'2024-06-03 14:37:59','2024-06-03 14:37:59',NULL,1,1,1,20,NULL,25,'Bibi Transfer','2024-06-03 23:18:00',NULL,NULL,NULL,0,0,1,1),
(22,'2024-06-03 14:39:56','2024-06-03 14:41:04',NULL,1,1,1,21,NULL,25,'Fare','2024-06-02 14:39:00',NULL,NULL,NULL,0,0,1,1),
(23,'2024-06-03 14:40:13','2024-06-03 14:41:21',NULL,1,1,1,22,NULL,25,'Grab Food','2024-06-02 14:40:00',NULL,NULL,NULL,0,0,1,1),
(24,'2024-06-03 14:40:38','2024-06-03 14:40:39',NULL,1,1,1,23,NULL,25,'Takoyaki','2024-06-02 14:40:00',NULL,NULL,NULL,0,0,1,1),
(25,'2024-06-03 14:40:54','2024-06-03 14:40:54',NULL,1,1,1,24,NULL,25,'Bottled Water','2024-06-02 14:40:00',NULL,NULL,NULL,0,0,1,1),
(26,'2024-06-03 14:41:55','2024-06-03 14:41:55',NULL,1,1,1,25,NULL,25,'Financial Help','2024-06-03 14:41:00',NULL,NULL,NULL,0,0,1,1),
(27,'2024-06-04 22:14:57','2024-06-04 22:14:58',NULL,1,1,1,26,NULL,25,'Bibi Transfer','2024-06-04 22:14:00',NULL,NULL,NULL,0,0,1,1),
(28,'2024-06-05 21:21:35','2024-06-05 21:21:35',NULL,1,1,3,27,NULL,25,'Savings Withdrawal','2024-06-05 18:42:00',NULL,NULL,NULL,0,0,1,1),
(29,'2024-06-05 21:22:54','2024-06-05 21:22:54',NULL,1,1,1,28,NULL,25,'Big Brew','2024-06-05 21:21:00',NULL,NULL,NULL,0,0,1,1),
(30,'2024-06-05 21:23:12','2024-06-05 21:23:12',NULL,1,1,3,29,NULL,25,'Savings Withdrawal','2024-06-05 21:22:00',NULL,NULL,NULL,0,0,1,1),
(31,'2024-06-05 21:25:16','2024-06-05 21:25:58',NULL,1,1,1,30,NULL,25,'Fashion','2024-06-05 21:03:00',NULL,NULL,NULL,0,0,1,1),
(32,'2024-06-05 21:29:14','2024-06-05 21:29:14',NULL,1,1,4,31,NULL,25,'Initial balance for \"Shopeepay\"','2024-06-15 00:00:00',NULL,NULL,NULL,0,0,1,1),
(33,'2024-06-05 21:29:14','2024-06-05 21:29:14','2024-06-05 21:29:14',1,1,7,32,NULL,25,'Liability credit for \"Shopeepay\"','2024-06-15 00:00:00',NULL,NULL,NULL,0,0,1,1),
(34,'2024-06-05 21:34:11','2024-06-05 21:34:11',NULL,1,1,4,33,NULL,25,'Initial balance for \"Shopeepay - Lexar NM710\"','2024-06-30 00:00:00',NULL,NULL,NULL,0,0,1,1),
(35,'2024-06-05 21:34:11','2024-06-05 21:34:11','2024-06-05 21:34:11',1,1,7,34,NULL,25,'Liability credit for \"Shopeepay - Lexar NM710\"','2024-06-30 00:00:00',NULL,NULL,NULL,0,0,1,1),
(36,'2024-06-05 22:58:12','2024-06-05 22:58:12',NULL,1,1,2,35,NULL,25,'Return Bibi Transfer','2024-06-05 22:57:00',NULL,NULL,NULL,0,0,1,1),
(37,'2024-06-06 00:08:02','2024-06-06 00:08:02',NULL,1,1,1,36,NULL,25,'Financial Help','2024-06-06 00:07:00',NULL,NULL,NULL,0,0,1,1),
(38,'2024-06-06 23:33:48','2024-06-06 23:37:49',NULL,1,1,1,37,NULL,25,'Financial Help','2024-06-06 21:37:00',NULL,NULL,NULL,0,0,1,1),
(39,'2024-06-06 23:35:18','2024-06-06 23:35:19',NULL,1,1,1,38,NULL,25,'Bibi Transfer','2024-06-06 09:38:00',NULL,NULL,NULL,0,0,1,1),
(40,'2024-06-06 23:35:59','2024-06-06 23:35:59',NULL,1,1,1,39,NULL,25,'Bibi Transfer','2024-06-06 13:43:00',NULL,NULL,NULL,0,0,1,1),
(41,'2024-06-07 22:11:01','2024-06-07 22:11:01',NULL,1,1,2,40,NULL,25,'Return Borrowed Money','2024-06-06 23:40:00',NULL,NULL,NULL,0,0,1,1),
(42,'2024-06-07 22:13:29','2024-06-07 22:37:21',NULL,1,1,2,41,NULL,25,'Return Borrowed Money','2024-06-07 09:10:00',NULL,NULL,NULL,0,0,1,1),
(43,'2024-06-07 22:16:58','2024-06-07 22:16:58',NULL,1,1,1,42,NULL,25,'Public Transpo Fare','2024-06-07 22:16:00',NULL,NULL,NULL,0,0,1,1),
(44,'2024-06-07 22:20:59','2024-06-07 22:20:59',NULL,1,1,1,43,NULL,25,'Starbucks','2024-06-07 14:30:00',NULL,NULL,NULL,0,0,1,1),
(45,'2024-06-07 22:23:04','2024-06-07 22:23:04',NULL,1,1,2,44,NULL,25,'Coworker Return Settled Amount','2024-06-07 22:21:00',NULL,NULL,NULL,0,0,1,1),
(46,'2024-06-07 22:24:13','2024-06-07 22:36:03',NULL,1,1,2,45,NULL,25,'Coworker Return Settled Amount','2024-06-07 16:00:00',NULL,NULL,NULL,0,0,1,1),
(47,'2024-06-07 22:28:39','2024-06-07 22:28:39',NULL,1,1,1,43,NULL,25,'Coworker Settle Amount','2024-06-07 14:30:00',NULL,NULL,NULL,0,0,1,1),
(48,'2024-06-07 22:29:35','2024-06-07 22:36:28',NULL,1,1,3,46,NULL,25,'Savings Withdrawal','2024-06-07 17:11:00',NULL,NULL,NULL,0,0,1,1),
(49,'2024-06-07 22:30:37','2024-06-07 22:35:45',NULL,1,1,1,47,NULL,25,'Surplus Zara Rust Knitted Polo','2024-06-07 17:14:00',NULL,NULL,NULL,0,0,1,1),
(50,'2024-06-07 22:32:42','2024-06-07 22:34:30','2024-06-07 22:34:30',1,1,2,48,NULL,25,'Savings Accumulated Daily Interest Rate','2024-06-07 22:32:00',NULL,NULL,NULL,0,0,1,1),
(51,'2024-06-07 22:35:21','2024-06-07 22:35:21',NULL,1,1,2,49,NULL,25,'Savings Accumulated Daily Interest','2024-06-07 22:34:00',NULL,NULL,NULL,0,0,1,1);
/*!40000 ALTER TABLE `transaction_journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_types`
--

DROP TABLE IF EXISTS `transaction_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_types_type_unique` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_types`
--

LOCK TABLES `transaction_types` WRITE;
/*!40000 ALTER TABLE `transaction_types` DISABLE KEYS */;
INSERT INTO `transaction_types` VALUES
(1,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Withdrawal'),
(2,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Deposit'),
(3,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Transfer'),
(4,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Opening balance'),
(5,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Reconciliation'),
(6,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Invalid'),
(7,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'Liability credit');
/*!40000 ALTER TABLE `transaction_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `reconciled` tinyint(1) NOT NULL DEFAULT 0,
  `account_id` int(10) unsigned NOT NULL,
  `transaction_journal_id` int(10) unsigned NOT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `transaction_currency_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(32,12) NOT NULL,
  `foreign_amount` decimal(32,12) DEFAULT NULL,
  `foreign_currency_id` int(10) unsigned DEFAULT NULL,
  `identifier` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `transactions_account_id_index` (`account_id`),
  KEY `transactions_transaction_journal_id_index` (`transaction_journal_id`),
  KEY `transactions_transaction_currency_id_index` (`transaction_currency_id`),
  KEY `transactions_foreign_currency_id_index` (`foreign_currency_id`),
  CONSTRAINT `transactions_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_foreign_currency_id_foreign` FOREIGN KEY (`foreign_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transactions_transaction_currency_id_foreign` FOREIGN KEY (`transaction_currency_id`) REFERENCES `transaction_currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transactions_transaction_journal_id_foreign` FOREIGN KEY (`transaction_journal_id`) REFERENCES `transaction_journals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES
(1,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,0,2,1,NULL,25,-6000.410000000000,NULL,NULL,0),
(2,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,0,1,1,NULL,25,6000.410000000000,NULL,NULL,0),
(3,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,0,4,2,NULL,25,-3900.780000000000,NULL,NULL,0),
(4,'2024-05-25 14:54:13','2024-05-25 14:54:13',NULL,0,3,2,NULL,25,3900.780000000000,NULL,NULL,0),
(5,'2024-05-25 14:54:54','2024-05-25 14:54:54',NULL,0,1,3,NULL,25,-2100.000000000000,NULL,NULL,0),
(6,'2024-05-25 14:54:54','2024-05-25 14:54:54',NULL,0,3,3,NULL,25,2100.000000000000,NULL,NULL,0),
(7,'2024-05-25 15:05:50','2024-06-09 15:02:45',NULL,0,1,4,NULL,25,-548.000000000000,NULL,NULL,0),
(8,'2024-05-25 15:05:50','2024-05-25 15:14:19',NULL,0,9,4,NULL,25,548.000000000000,NULL,NULL,0),
(9,'2024-05-25 15:05:50','2024-06-09 15:02:45',NULL,0,1,5,NULL,25,-154.000000000000,NULL,NULL,0),
(10,'2024-05-25 15:05:50','2024-05-25 15:14:19',NULL,0,9,5,NULL,25,154.000000000000,NULL,NULL,0),
(11,'2024-05-25 15:08:21','2024-05-25 15:08:21',NULL,0,1,6,NULL,25,-75.000000000000,NULL,NULL,0),
(12,'2024-05-25 15:08:21','2024-05-25 15:15:18',NULL,0,9,6,NULL,25,75.000000000000,NULL,NULL,0),
(13,'2024-05-25 15:09:17','2024-05-25 15:09:17',NULL,0,1,7,NULL,25,-179.000000000000,NULL,NULL,0),
(14,'2024-05-25 15:09:17','2024-05-25 15:17:20',NULL,0,9,7,NULL,25,179.000000000000,NULL,NULL,0),
(15,'2024-05-25 15:09:41','2024-05-25 15:09:41',NULL,0,1,8,NULL,25,-1550.000000000000,NULL,NULL,0),
(16,'2024-05-25 15:09:41','2024-05-25 15:16:13',NULL,0,8,8,NULL,25,1550.000000000000,NULL,NULL,0),
(17,'2024-05-25 15:11:08','2024-05-25 15:11:08',NULL,0,1,9,NULL,25,-248.000000000000,NULL,NULL,0),
(18,'2024-05-25 15:11:08','2024-05-25 15:11:08',NULL,0,9,9,NULL,25,248.000000000000,NULL,NULL,0),
(19,'2024-05-25 15:12:18','2024-05-25 15:12:18',NULL,0,1,10,NULL,25,-515.000000000000,NULL,NULL,0),
(20,'2024-05-25 15:12:18','2024-05-25 15:12:18',NULL,0,9,10,NULL,25,515.000000000000,NULL,NULL,0),
(21,'2024-05-25 15:13:21','2024-05-25 15:13:21',NULL,0,1,11,NULL,25,-515.000000000000,NULL,NULL,0),
(22,'2024-05-25 15:13:21','2024-05-25 15:13:21',NULL,0,8,11,NULL,25,515.000000000000,NULL,NULL,0),
(23,'2024-05-31 14:06:48','2024-05-31 14:06:48',NULL,0,1,12,NULL,25,-113.680000000000,NULL,NULL,0),
(24,'2024-05-31 14:06:48','2024-05-31 14:06:48',NULL,0,9,12,NULL,25,113.680000000000,NULL,NULL,0),
(25,'2024-05-31 14:09:59','2024-05-31 14:10:13',NULL,0,10,13,NULL,25,-5500.000000000000,NULL,NULL,0),
(26,'2024-05-31 14:09:59','2024-05-31 14:10:13',NULL,0,1,13,NULL,25,5500.000000000000,NULL,NULL,0),
(27,'2024-05-31 14:11:28','2024-05-31 14:11:28',NULL,0,1,14,NULL,25,-2000.000000000000,NULL,NULL,0),
(28,'2024-05-31 14:11:28','2024-05-31 14:11:28',NULL,0,3,14,NULL,25,2000.000000000000,NULL,NULL,0),
(29,'2024-05-31 23:14:22','2024-05-31 23:14:22',NULL,0,1,15,NULL,25,-115.000000000000,NULL,NULL,0),
(30,'2024-05-31 23:14:22','2024-05-31 23:14:22',NULL,0,9,15,NULL,25,115.000000000000,NULL,NULL,0),
(31,'2024-05-31 23:18:13','2024-05-31 23:18:13',NULL,0,1,16,NULL,25,-1218.000000000000,NULL,NULL,0),
(32,'2024-05-31 23:18:13','2024-05-31 23:18:13',NULL,0,8,16,NULL,25,1218.000000000000,NULL,NULL,0),
(33,'2024-05-31 23:18:55','2024-05-31 23:18:55',NULL,0,1,17,NULL,25,-500.000000000000,NULL,NULL,0),
(34,'2024-05-31 23:18:55','2024-05-31 23:18:55',NULL,0,5,17,NULL,25,500.000000000000,NULL,NULL,0),
(35,'2024-05-31 23:20:07','2024-05-31 23:20:07',NULL,0,1,18,NULL,25,-224.000000000000,NULL,NULL,0),
(36,'2024-05-31 23:20:07','2024-05-31 23:20:07',NULL,0,9,18,NULL,25,224.000000000000,NULL,NULL,0),
(37,'2024-05-31 23:22:35','2024-05-31 23:22:35',NULL,0,6,19,NULL,25,-18.000000000000,NULL,NULL,0),
(38,'2024-05-31 23:22:35','2024-05-31 23:22:35',NULL,0,1,19,NULL,25,18.000000000000,NULL,NULL,0),
(39,'2024-06-03 14:36:05','2024-06-03 14:36:05',NULL,0,1,20,NULL,25,-154.000000000000,NULL,NULL,0),
(40,'2024-06-03 14:36:05','2024-06-03 14:36:05',NULL,0,9,20,NULL,25,154.000000000000,NULL,NULL,0),
(41,'2024-06-03 14:37:59','2024-06-03 14:39:03',NULL,0,1,21,NULL,25,-545.000000000000,NULL,NULL,0),
(42,'2024-06-03 14:37:59','2024-06-03 14:39:03',NULL,0,9,21,NULL,25,545.000000000000,NULL,NULL,0),
(43,'2024-06-03 14:39:56','2024-06-03 14:39:56',NULL,0,5,22,NULL,25,-104.000000000000,NULL,NULL,0),
(44,'2024-06-03 14:39:56','2024-06-03 14:41:04',NULL,0,9,22,NULL,25,104.000000000000,NULL,NULL,0),
(45,'2024-06-03 14:40:13','2024-06-03 14:40:13',NULL,0,5,23,NULL,25,-244.000000000000,NULL,NULL,0),
(46,'2024-06-03 14:40:13','2024-06-03 14:41:21',NULL,0,9,23,NULL,25,244.000000000000,NULL,NULL,0),
(47,'2024-06-03 14:40:38','2024-06-03 14:40:38',NULL,0,5,24,NULL,25,-85.000000000000,NULL,NULL,0),
(48,'2024-06-03 14:40:38','2024-06-03 14:40:38',NULL,0,9,24,NULL,25,85.000000000000,NULL,NULL,0),
(49,'2024-06-03 14:40:54','2024-06-03 14:40:54',NULL,0,5,25,NULL,25,-15.000000000000,NULL,NULL,0),
(50,'2024-06-03 14:40:54','2024-06-03 14:40:54',NULL,0,9,25,NULL,25,15.000000000000,NULL,NULL,0),
(51,'2024-06-03 14:41:55','2024-06-03 14:41:55',NULL,0,5,26,NULL,25,-50.000000000000,NULL,NULL,0),
(52,'2024-06-03 14:41:55','2024-06-03 14:41:55',NULL,0,9,26,NULL,25,50.000000000000,NULL,NULL,0),
(53,'2024-06-04 22:14:57','2024-06-04 22:14:57',NULL,0,1,27,NULL,25,-737.000000000000,NULL,NULL,0),
(54,'2024-06-04 22:14:57','2024-06-04 22:14:57',NULL,0,9,27,NULL,25,737.000000000000,NULL,NULL,0),
(55,'2024-06-05 21:21:35','2024-06-05 21:21:35',NULL,0,3,28,NULL,25,-140.000000000000,NULL,NULL,0),
(56,'2024-06-05 21:21:35','2024-06-05 21:21:35',NULL,0,1,28,NULL,25,140.000000000000,NULL,NULL,0),
(57,'2024-06-05 21:22:54','2024-06-05 21:22:54',NULL,0,1,29,NULL,25,-93.000000000000,NULL,NULL,0),
(58,'2024-06-05 21:22:54','2024-06-05 21:22:54',NULL,0,9,29,NULL,25,93.000000000000,NULL,NULL,0),
(59,'2024-06-05 21:23:12','2024-06-05 21:23:12',NULL,0,3,30,NULL,25,-600.000000000000,NULL,NULL,0),
(60,'2024-06-05 21:23:12','2024-06-05 21:23:12',NULL,0,1,30,NULL,25,600.000000000000,NULL,NULL,0),
(61,'2024-06-05 21:25:16','2024-06-05 21:25:58',NULL,0,1,31,NULL,25,-377.000000000000,NULL,NULL,0),
(62,'2024-06-05 21:25:16','2024-06-05 21:25:58',NULL,0,9,31,NULL,25,377.000000000000,NULL,NULL,0),
(63,'2024-06-05 21:29:14','2024-06-05 21:29:14',NULL,0,13,32,NULL,25,674.490000000000,NULL,NULL,0),
(64,'2024-06-05 21:29:14','2024-06-05 21:29:14',NULL,0,12,32,NULL,25,-674.490000000000,NULL,NULL,0),
(65,'2024-06-05 21:29:14','2024-06-05 21:29:14','2024-06-05 21:29:14',0,12,33,NULL,25,-674.490000000000,NULL,NULL,0),
(66,'2024-06-05 21:29:14','2024-06-05 21:29:14','2024-06-05 21:29:14',0,14,33,NULL,25,674.490000000000,NULL,NULL,0),
(67,'2024-06-05 21:34:11','2024-06-05 21:34:11',NULL,0,16,34,NULL,25,3081.000000000000,NULL,NULL,0),
(68,'2024-06-05 21:34:11','2024-06-05 21:34:11',NULL,0,15,34,NULL,25,-3081.000000000000,NULL,NULL,0),
(69,'2024-06-05 21:34:11','2024-06-05 21:34:11','2024-06-05 21:34:11',0,15,35,NULL,25,-3081.000000000000,NULL,NULL,0),
(70,'2024-06-05 21:34:11','2024-06-05 21:34:11','2024-06-05 21:34:11',0,17,35,NULL,25,3081.000000000000,NULL,NULL,0),
(71,'2024-06-05 22:58:12','2024-06-05 22:58:12',NULL,0,6,36,NULL,25,-740.000000000000,NULL,NULL,0),
(72,'2024-06-05 22:58:12','2024-06-05 22:58:12',NULL,0,1,36,NULL,25,740.000000000000,NULL,NULL,0),
(73,'2024-06-06 00:08:02','2024-06-06 00:08:38',NULL,0,1,37,NULL,25,-160.000000000000,NULL,NULL,0),
(74,'2024-06-06 00:08:02','2024-06-06 00:08:38',NULL,0,9,37,NULL,25,160.000000000000,NULL,NULL,0),
(75,'2024-06-06 23:33:48','2024-06-06 23:33:48',NULL,0,1,38,NULL,25,-530.000000000000,NULL,NULL,0),
(76,'2024-06-06 23:33:48','2024-06-07 22:14:42',NULL,0,8,38,NULL,25,530.000000000000,NULL,NULL,0),
(77,'2024-06-06 23:35:18','2024-06-06 23:35:18',NULL,0,1,39,NULL,25,-142.000000000000,NULL,NULL,0),
(78,'2024-06-06 23:35:18','2024-06-06 23:35:18',NULL,0,9,39,NULL,25,142.000000000000,NULL,NULL,0),
(79,'2024-06-06 23:35:59','2024-06-06 23:37:24',NULL,0,1,40,NULL,25,-143.000000000000,NULL,NULL,0),
(80,'2024-06-06 23:35:59','2024-06-06 23:37:24',NULL,0,9,40,NULL,25,143.000000000000,NULL,NULL,0),
(81,'2024-06-07 22:11:01','2024-06-07 22:11:01',NULL,0,6,41,NULL,25,-120.000000000000,NULL,NULL,0),
(82,'2024-06-07 22:11:01','2024-06-07 22:11:01',NULL,0,5,41,NULL,25,120.000000000000,NULL,NULL,0),
(83,'2024-06-07 22:13:29','2024-06-07 22:13:29',NULL,0,6,42,NULL,25,-500.000000000000,NULL,NULL,0),
(84,'2024-06-07 22:13:29','2024-06-07 22:37:21',NULL,0,5,42,NULL,25,500.000000000000,NULL,NULL,0),
(85,'2024-06-07 22:16:58','2024-06-07 22:16:58',NULL,0,5,43,NULL,25,-172.000000000000,NULL,NULL,0),
(86,'2024-06-07 22:16:58','2024-06-07 22:16:58',NULL,0,9,43,NULL,25,172.000000000000,NULL,NULL,0),
(87,'2024-06-07 22:20:59','2024-06-09 15:02:45',NULL,0,5,44,NULL,25,-200.000000000000,NULL,NULL,0),
(88,'2024-06-07 22:20:59','2024-06-07 22:28:39',NULL,0,9,44,NULL,25,200.000000000000,NULL,NULL,0),
(89,'2024-06-07 22:23:04','2024-06-07 22:23:04',NULL,0,6,45,NULL,25,-250.000000000000,NULL,NULL,0),
(90,'2024-06-07 22:23:04','2024-06-07 22:23:04',NULL,0,5,45,NULL,25,250.000000000000,NULL,NULL,0),
(91,'2024-06-07 22:24:13','2024-06-07 22:24:13',NULL,0,6,46,NULL,25,-50.000000000000,NULL,NULL,0),
(92,'2024-06-07 22:24:13','2024-06-07 22:36:03',NULL,0,1,46,NULL,25,50.000000000000,NULL,NULL,0),
(93,'2024-06-07 22:28:39','2024-06-09 15:02:45',NULL,0,5,47,NULL,25,-300.000000000000,NULL,NULL,0),
(94,'2024-06-07 22:28:39','2024-06-07 22:28:39',NULL,0,9,47,NULL,25,300.000000000000,NULL,NULL,0),
(95,'2024-06-07 22:29:35','2024-06-07 22:29:50',NULL,0,3,48,NULL,25,-503.000000000000,NULL,NULL,0),
(96,'2024-06-07 22:29:35','2024-06-07 22:36:28',NULL,0,1,48,NULL,25,503.000000000000,NULL,NULL,0),
(97,'2024-06-07 22:30:37','2024-06-07 22:30:37',NULL,0,1,49,NULL,25,-615.000000000000,NULL,NULL,0),
(98,'2024-06-07 22:30:37','2024-06-07 22:35:45',NULL,0,9,49,NULL,25,615.000000000000,NULL,NULL,0),
(99,'2024-06-07 22:32:42','2024-06-07 22:34:30','2024-06-07 22:34:30',0,6,50,NULL,25,-4.720000000000,NULL,NULL,0),
(100,'2024-06-07 22:32:42','2024-06-07 22:34:30','2024-06-07 22:34:30',0,3,50,NULL,25,4.720000000000,NULL,NULL,0),
(101,'2024-06-07 22:35:21','2024-06-07 22:35:21',NULL,0,6,51,NULL,25,-5.170000000000,NULL,NULL,0),
(102,'2024-06-07 22:35:21','2024-06-07 22:35:21',NULL,0,3,51,NULL,25,5.170000000000,NULL,NULL,0);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_groups_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` VALUES
(1,'2024-05-25 14:51:59','2024-05-25 14:51:59',NULL,'prlorence.finance@gmail.com');
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_roles_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES
(1,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'ro'),
(2,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'mng_trx'),
(3,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'mng_meta'),
(4,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'mng_budgets'),
(5,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'mng_piggies'),
(6,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'mng_subscriptions'),
(7,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'mng_rules'),
(8,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'mng_recurring'),
(9,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'mng_webhooks'),
(10,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'mng_currencies'),
(11,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'view_reports'),
(12,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'view_memberships'),
(13,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'full'),
(14,'2024-05-25 14:51:01','2024-05-25 14:51:01',NULL,'owner');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `objectguid` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(60) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `reset` varchar(32) DEFAULT NULL,
  `blocked` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `blocked_code` varchar(25) DEFAULT NULL,
  `mfa_secret` varchar(50) DEFAULT NULL,
  `domain` varchar(191) DEFAULT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type_user_group_id` (`user_group_id`),
  CONSTRAINT `type_user_group_id` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,NULL,'2024-05-25 14:51:59','2024-05-25 14:51:59','prlorence.finance@gmail.com','$2y$10$lIl3eMEILfi3vhVjCTh.9.mYFq/.h5RYxf6jZ3ERRhpAmH2a9miJy','MioyROo1SEeCuM2L64YGPfrkKi678pFTqjbLF8gapjLDOktzJsy6wthKNTTf',NULL,0,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_attempts`
--

DROP TABLE IF EXISTS `webhook_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webhook_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `webhook_message_id` int(10) unsigned NOT NULL,
  `status_code` smallint(5) unsigned NOT NULL DEFAULT 0,
  `logs` longtext DEFAULT NULL,
  `response` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webhook_attempts_webhook_message_id_foreign` (`webhook_message_id`),
  CONSTRAINT `webhook_attempts_webhook_message_id_foreign` FOREIGN KEY (`webhook_message_id`) REFERENCES `webhook_messages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_attempts`
--

LOCK TABLES `webhook_attempts` WRITE;
/*!40000 ALTER TABLE `webhook_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_messages`
--

DROP TABLE IF EXISTS `webhook_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webhook_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `errored` tinyint(1) NOT NULL DEFAULT 0,
  `webhook_id` int(10) unsigned NOT NULL,
  `uuid` varchar(64) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `webhook_messages_webhook_id_foreign` (`webhook_id`),
  CONSTRAINT `webhook_messages_webhook_id_foreign` FOREIGN KEY (`webhook_id`) REFERENCES `webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_messages`
--

LOCK TABLES `webhook_messages` WRITE;
/*!40000 ALTER TABLE `webhook_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhooks`
--

DROP TABLE IF EXISTS `webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webhooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `secret` varchar(32) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `trigger` smallint(5) unsigned NOT NULL,
  `response` smallint(5) unsigned NOT NULL,
  `delivery` smallint(5) unsigned NOT NULL,
  `url` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `webhooks_user_id_foreign` (`user_id`),
  KEY `webhooks_title_index` (`title`),
  KEY `webhooks_secret_index` (`secret`),
  KEY `webhooks_to_ugi` (`user_group_id`),
  CONSTRAINT `webhooks_to_ugi` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `webhooks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhooks`
--

LOCK TABLES `webhooks` WRITE;
/*!40000 ALTER TABLE `webhooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhooks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-09  7:05:43
